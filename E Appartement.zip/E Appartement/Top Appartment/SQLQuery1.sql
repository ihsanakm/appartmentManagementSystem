create database Top_Appartment ;

use  Top_Appartment ;

create table user_Manage
(
UserID varchar(50), 
UserName varchar(255),
UserType varchar(25),
BirthOfDate varchar(255),
Address varchar(255),
phoneNumber int,
mail varchar(50),
password varchar(25),
PRIMARY KEY (UserID)
)

--drop table user_Manage

create table Customer_Manage
(
CustomerID varchar(50),
CustomerName varchar(255),
Address varchar(255),
phoneNumber int,
mail varchar(50),
NIC varchar(255),
PRIMARY KEY (CustomerID)
)

---drop table Customer_Manage---

create table Apartment_Manage
(
ApartmentID varchar(50),
Type varchar(255),
Address varchar(255),
Rent int,
DateofOccupancy varchar(255),
Status varchar(50),
PRIMARY KEY (ApartmentID)
)

---drop table Apartment_Manage---

create table Lease_Manage
(
LeaseID varchar(50),
ApartmentID varchar(50),
CustomerID varchar(50),
dependent varchar(25),
servent varchar(25),
Parkingspaces varchar(50),
LeasePeriod varchar(25),
LeaseStartDate varchar(25),
LeaseEndDate varchar(25),
Rent int,
Advance int,
PRIMARY KEY (LeaseID),
foreign key (ApartmentID) references Apartment_Manage(ApartmentID),
foreign key (CustomerID) references Customer_Manage(CustomerID)

)

select MONTH(LeaseStartDate) as 'month',sum(Advance)  from Lease_Manage group by( MONTH(LeaseStartDate))


---drop table Lease_Manage---


create table Maintenance_Manage
(
MaintenanceID varchar(50),
ApartmentID varchar(50),
Description varchar(50),
AssignedTo varchar(50),
StartDate varchar(50),
EandDate varchar(50),
Status varchar(255),
PRIMARY KEY (MaintenanceID)
)

Alter table Maintenance_Manage add foreign key(ApartmentID) references Apartment_Manage(ApartmentID)

---drop table Maintenance_Manage---

create table Customer_Lease_Extension_Request
(
LeaseID varchar(50),
CurrentLeasePeriod varchar(50),
Rent int,
ApartmentID varchar(25),
RequestedLeasePeriod varchar(25),
Advance int,
Reasonforextension varchar(225),
Request varchar(25),
PRIMARY KEY (LeaseID),
)

---drop table Customer_Lease_Extension_Request---