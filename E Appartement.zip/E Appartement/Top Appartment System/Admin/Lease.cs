﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace E_Appartment.Admin
{
    public partial class Lease : Form
    {

        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-PBEM3OT\SQLEXPRESS;Initial Catalog=Top_Appartment;Integrated Security=True");

        public Lease()
        {
            InitializeComponent();
        }

        private void Lease_Load(object sender, EventArgs e)
        {
            load();
        }
        void load()
        {
            try
            {
                con.Open();
                string sql = "select * from Lease_Manage;";
                SqlDataAdapter adapter = new SqlDataAdapter(sql, con);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dataGridView_Lease.DataSource = dt;
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void Btn_save_Click(object sender, EventArgs e)
        {
            if (txt_LeaseID.Text == "")
            {
                MessageBox.Show("fill all field");
            }
            else
            {
                try
                {
                    con.Open();
                    string LeaseStartDate = txt_LeaseStartDate.Value.ToString("yyyy/MM/dd");
                    string LeaseEndDate = txt_LeaseEndDate.Value.ToString("yyyy/MM/dd");
                    string q1 = "insert into Lease_Manage values ('" + txt_LeaseID.Text + "','" + txt_ApartmentID.Text + "','" + txt_CustomerID.Text + "','" + txt_dependent.Text + "','" + comboBox_servent.Text + "','" + comboBox_ParkingSpaces.Text + "','" + txt_LeasePeriod.Text + "','" + LeaseStartDate + "','" + LeaseEndDate + "','" + txt_Rent.Text + "','" + txt_Advance.Text + "');";
                    MessageBox.Show(q1);
                    SqlCommand comd1 = new SqlCommand(q1, con);
                    int i = comd1.ExecuteNonQuery();
                    con.Close();

                    if (i > 0)
                    {
                        load();
                        MessageBox.Show("Insert successfully", "information", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    }
                    else
                    {
                        MessageBox.Show("Error", "alert", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                    con.Close();
                }


            }
        }

        private void Btn_clear_Click(object sender, EventArgs e)
        {
            txt_LeaseID.Text = "";
            txt_ApartmentID.Clear();
            txt_CustomerID.Clear();
            txt_dependent.Clear();
            comboBox_servent.Items.Clear();
            comboBox_ParkingSpaces.Items.Clear();
            txt_LeasePeriod.Clear();
            txt_LeaseStartDate.ResetText();
            txt_LeaseEndDate.ResetText();
            txt_Rent.Clear();
            txt_Advance.Clear();

            btn_update.Enabled = false;
            btn_delete.Enabled = false;
            txt_LeaseID.Enabled = true;
        }

        private void Btn_delete_Click(object sender, EventArgs e)
        {
            if (txt_LeaseID.Text == "")
            {
                MessageBox.Show("fill all field");
            }
            else
            {
                try
                {
                    con.Open();
                    string LeaseStartDate = txt_LeaseStartDate.Value.ToString("yyyy/MM/dd");
                    string LeaseEndDate = txt_LeaseEndDate.Value.ToString("yyyy/MM/dd");
                    string q1 = "delete  Lease_Manage  where LeaseID = '" + txt_LeaseID.Text + "'";
                    SqlCommand comd1 = new SqlCommand(q1, con);
                    int i = comd1.ExecuteNonQuery();
                    con.Close();

                    if (i > 0)
                    {
                        MessageBox.Show("delete successfully", "information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        load();
                        btn_update.Enabled = false;/// Disable Button
                        btn_delete.Enabled = false;
                        txt_ApartmentID.Enabled = true;
                    }
                    else
                    {
                        MessageBox.Show("Error", "alert", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }


            }
        }

        private void DataGridView_Lease_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {

                txt_LeaseID.Text = dataGridView_Lease.Rows[e.RowIndex].Cells[0].Value.ToString();
                txt_ApartmentID.Text = dataGridView_Lease.Rows[e.RowIndex].Cells[1].Value.ToString();
                txt_CustomerID.Text = dataGridView_Lease.Rows[e.RowIndex].Cells[2].Value.ToString();
                txt_dependent.Text = dataGridView_Lease.Rows[e.RowIndex].Cells[3].Value.ToString();
                comboBox_servent.Text = dataGridView_Lease.Rows[e.RowIndex].Cells[4].Value.ToString();
                comboBox_ParkingSpaces.Text = dataGridView_Lease.Rows[e.RowIndex].Cells[5].Value.ToString();
                txt_LeasePeriod.Text = dataGridView_Lease.Rows[e.RowIndex].Cells[6].Value.ToString();
                txt_LeaseStartDate.Text = dataGridView_Lease.Rows[e.RowIndex].Cells[7].Value.ToString();
                txt_LeaseEndDate.Text = dataGridView_Lease.Rows[e.RowIndex].Cells[8].Value.ToString();
                txt_Rent.Text = dataGridView_Lease.Rows[e.RowIndex].Cells[9].Value.ToString();
                txt_Advance.Text = dataGridView_Lease.Rows[e.RowIndex].Cells[10].Value.ToString();

                btn_update.Enabled = true;
                btn_delete.Enabled = true;

                txt_LeaseID.Enabled = false;
            }
        }

        private void Btn_update_Click(object sender, EventArgs e)
        {
            if (txt_LeaseID.Text == "")
            {
                MessageBox.Show("fill all field");
            }
            else
            {
                try
                {
                    con.Open();
                    string LeaseStartDate = txt_LeaseStartDate.Value.ToString("yyyy/MM/dd");
                    string LeaseEndDate = txt_LeaseEndDate.Value.ToString("yyyy/MM/dd");
                    string q2 = " update Lease_Manage set ApartmentID='" + txt_ApartmentID.Text + "',CustomerID='" + txt_CustomerID.Text + "',dependent='" + txt_dependent.Text + "',servent='" + comboBox_servent.Text + "',Parkingspaces='" + comboBox_ParkingSpaces.Text + "',LeasePeriod='" + txt_LeasePeriod.Text + "',LeaseStartDate='" + LeaseStartDate + "',LeaseEndDate='" + LeaseEndDate + "',Rent='" + txt_Rent.Text + "',Advance='" + txt_Advance.Text + "';";
                    SqlCommand comd2 = new SqlCommand(q2, con);
                    int i = comd2.ExecuteNonQuery();
                    con.Close();

                    if (i > 0)
                    {

                        MessageBox.Show("update successfully", "information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        load();
                        btn_update.Enabled = false;
                        btn_delete.Enabled = false;
                        txt_LeaseID.Enabled = true;
                    }
                    else
                    {
                        MessageBox.Show("Error", "alert", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                    con.Close();
                }
            }
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }
    }
}
