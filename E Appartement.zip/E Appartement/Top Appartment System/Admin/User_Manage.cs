﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace E_Appartment
{
    public partial class User_Manage : Form
    {

        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-PBEM3OT\SQLEXPRESS;Initial Catalog=Top_Appartment;Integrated Security=True");

        public User_Manage()
        {
            InitializeComponent();
        }


        private void User_Manage_Load(object sender, EventArgs e)
        {
            load();
        }

        void load()
        {
            try
            {
                con.Open();
                string sql = "select * from user_Manage;";
                SqlDataAdapter adapter = new SqlDataAdapter(sql, con);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dataGridView_User.DataSource = dt;
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        private void Btn_save_Click(object sender, EventArgs e)
        {

            if (txt_userid.Text == "" || txt_username.Text == "")
            {
                MessageBox.Show("fill all field");
            }
            else
            {
                try
                {
                    con.Open();
                    string bod = txt_BOD.Value.ToString("yyyy/MM/dd");
                    string q1 = "insert into user_Manage values ('" + txt_userid.Text + "','" + txt_username.Text + "','" + comboBox_UserType.Text + "','" + bod + "','" + txt_address.Text + "','" + txt_phonenumber.Text + "','" + txt_mail.Text + "','" + txt_password.Text + "');";
                    MessageBox.Show(q1);
                    SqlCommand comd1 = new SqlCommand(q1, con);
                    int i = comd1.ExecuteNonQuery();
                    con.Close();

                    if (i > 0)
                    {
                        load();
                        MessageBox.Show("Insert successfully", "information", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    }
                    else
                    {
                        MessageBox.Show("Error", "alert", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                    con.Close();
                }


            }



        }

        private void Btn_clear_Click(object sender, EventArgs e)
        {
            txt_userid.Text = "";
            txt_username.Clear();
            comboBox_UserType.Items.Clear();
            txt_address.Clear();
            txt_phonenumber.Clear();
            txt_mail.Clear();
            txt_password.Clear();
            txt_BOD.ResetText();

            btn_update.Enabled = false;
            btn_delete.Enabled = false;
            txt_userid.Enabled = true;
        }

        private void Btn_delete_Click(object sender, EventArgs e)
        {

            if (txt_userid.Text == "")
            {
                MessageBox.Show("fill all field");
            }
            else
            {
                try
                {
                    con.Open();
                    string bod = txt_BOD.Value.ToString("yyyy/MM/dd");
                    string q1 = "delete user_Manage where UserID = '" + txt_userid.Text + "'";
                    SqlCommand comd1 = new SqlCommand(q1, con);
                    int i = comd1.ExecuteNonQuery();
                    con.Close();

                    if (i > 0)
                    {
                        MessageBox.Show("delete successfully", "information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        load();
                        btn_update.Enabled = false;
                        btn_delete.Enabled = false;
                        txt_userid.Enabled = true;
                    }
                    else
                    {
                        MessageBox.Show("Error", "alert", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }


            }

        }

        private void DataGridView_User_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            if (e.RowIndex >= 0)
            {

                txt_userid.Text = dataGridView_User.Rows[e.RowIndex].Cells[0].Value.ToString();
                txt_username.Text = dataGridView_User.Rows[e.RowIndex].Cells[1].Value.ToString();
                comboBox_UserType.Text = dataGridView_User.Rows[e.RowIndex].Cells[2].Value.ToString();
                txt_phonenumber.Text = dataGridView_User.Rows[e.RowIndex].Cells[5].Value.ToString();
                txt_mail.Text = dataGridView_User.Rows[e.RowIndex].Cells[6].Value.ToString();
                txt_BOD.Text = dataGridView_User.Rows[e.RowIndex].Cells[3].Value.ToString();
                txt_address.Text = dataGridView_User.Rows[e.RowIndex].Cells[4].Value.ToString();
                txt_password.Text = dataGridView_User.Rows[e.RowIndex].Cells[7].Value.ToString();

                btn_update.Enabled = true;
                btn_delete.Enabled = true;

                txt_userid.Enabled = false;
            }

        }

        private void Btn_update_Click(object sender, EventArgs e)
        {

            if (txt_userid.Text == "")
            {
                MessageBox.Show("fill all field");
            }
            else
            {
                try
                {
                    con.Open();
                    string bod = txt_BOD.Value.ToString("yyyy/MM/dd");
                    string q2 = " update user_Manage set UserName='" + txt_username.Text + "',UserType='" + comboBox_UserType.Text + "',BirthOfDate='" + bod + "',Address='" + txt_address.Text + "',phoneNumber='" + txt_phonenumber.Text + "',mail='" + txt_mail.Text + "' where UserID='" + txt_userid.Text + "';";
                    SqlCommand comd2 = new SqlCommand(q2, con);
                    int i = comd2.ExecuteNonQuery();
                    con.Close();

                    if (i > 0)
                    {

                        MessageBox.Show("update successfully", "information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        load();
                        btn_update.Enabled = false;
                        btn_delete.Enabled = false;
                        txt_userid.Enabled = true;
                    }
                    else
                    {
                        MessageBox.Show("Error", "alert", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                    con.Close();
                }
            }

        }
    }
}
