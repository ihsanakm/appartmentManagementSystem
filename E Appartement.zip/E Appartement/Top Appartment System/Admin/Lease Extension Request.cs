﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace E_Appartment.Admin
{
    public partial class Lease_Extension_Request : Form
    {

        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-PBEM3OT\SQLEXPRESS;Initial Catalog=Top_Appartment;Integrated Security=True");
        public Lease_Extension_Request()
        {
            InitializeComponent();
        }

        private void Lease_Extension_Request_Load(object sender, EventArgs e)
        {
            load();
        }

        void load()
        {
            try
            {
                con.Open();
                string sql = "select * from Customer_Lease_Extension_Request;";
                SqlDataAdapter adapter = new SqlDataAdapter(sql, con);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dataGridView_Admin_Lease_Extension_Request.DataSource = dt;
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void DataGridView_Admin_Lease_Extension_Request_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            ID.Text = dataGridView_Admin_Lease_Extension_Request.Rows[e.RowIndex].Cells[0].Value.ToString();
        }

        private void Btn_Accept_Click(object sender, EventArgs e)
        {
            
              /// Update Request Status
                    con.Open();
                    string q2 = " update Customer_Lease_Extension_Request set Request='Accepted' where LeaseID='"+ dataGridView_Admin_Lease_Extension_Request.SelectedCells[0].Value.ToString() + "'";
                    SqlCommand comd2 = new SqlCommand(q2, con);
                    int i = comd2.ExecuteNonQuery();
                    con.Close();

                    if (i > 0)
                    {

                        MessageBox.Show("Update successfully", "information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        load();

                    }
                    else
                    {
                        MessageBox.Show("Error", "alert", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    }

        }

        private void Btn_Decline_Click(object sender, EventArgs e)
        {

            con.Open();
            string q2 = " update Customer_Lease_Extension_Request set request='Declined' where LeaseID='" + dataGridView_Admin_Lease_Extension_Request.SelectedCells[0].Value.ToString() + "'";
            SqlCommand comd2 = new SqlCommand(q2, con);
            int i = comd2.ExecuteNonQuery();
            con.Close();

            if (i > 0)
            {

                MessageBox.Show("update successfully", "information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                load();

            }
            else
            {
                MessageBox.Show("Error", "alert", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void DataGridView_Admin_Lease_Extension_Request_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }  
}
