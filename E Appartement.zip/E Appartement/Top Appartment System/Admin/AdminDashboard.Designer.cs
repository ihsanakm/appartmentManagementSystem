﻿namespace E_Appartment
{
    partial class AdminDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.BTN_Maintenance = new System.Windows.Forms.Button();
            this.BTN_User = new System.Windows.Forms.Button();
            this.BTN_ApartmentReport = new System.Windows.Forms.Button();
            this.pnlnav = new System.Windows.Forms.Panel();
            this.BTN_LOGOUT = new System.Windows.Forms.Button();
            this.BTN_Request = new System.Windows.Forms.Button();
            this.BTN_Customer = new System.Windows.Forms.Button();
            this.BTN_Lease = new System.Windows.Forms.Button();
            this.BTN_Apartment = new System.Windows.Forms.Button();
            this.BTN_Dashboard = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lblHead = new System.Windows.Forms.Label();
            this.pnl_Main = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.panel1.Controls.Add(this.BTN_Maintenance);
            this.panel1.Controls.Add(this.BTN_User);
            this.panel1.Controls.Add(this.BTN_ApartmentReport);
            this.panel1.Controls.Add(this.pnlnav);
            this.panel1.Controls.Add(this.BTN_LOGOUT);
            this.panel1.Controls.Add(this.BTN_Request);
            this.panel1.Controls.Add(this.BTN_Customer);
            this.panel1.Controls.Add(this.BTN_Lease);
            this.panel1.Controls.Add(this.BTN_Apartment);
            this.panel1.Controls.Add(this.BTN_Dashboard);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(188, 640);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.Panel1_Paint);
            // 
            // BTN_Maintenance
            // 
            this.BTN_Maintenance.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.BTN_Maintenance.Dock = System.Windows.Forms.DockStyle.Top;
            this.BTN_Maintenance.FlatAppearance.BorderSize = 0;
            this.BTN_Maintenance.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTN_Maintenance.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_Maintenance.ForeColor = System.Drawing.Color.SteelBlue;
            this.BTN_Maintenance.Location = new System.Drawing.Point(0, 539);
            this.BTN_Maintenance.Margin = new System.Windows.Forms.Padding(2);
            this.BTN_Maintenance.Name = "BTN_Maintenance";
            this.BTN_Maintenance.Size = new System.Drawing.Size(188, 64);
            this.BTN_Maintenance.TabIndex = 2;
            this.BTN_Maintenance.Text = "Maintenance";
            this.BTN_Maintenance.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BTN_Maintenance.UseVisualStyleBackColor = false;
            this.BTN_Maintenance.Click += new System.EventHandler(this.BTN_Maintenance_Click_1);
            // 
            // BTN_User
            // 
            this.BTN_User.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.BTN_User.Dock = System.Windows.Forms.DockStyle.Top;
            this.BTN_User.FlatAppearance.BorderSize = 0;
            this.BTN_User.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTN_User.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_User.ForeColor = System.Drawing.Color.SteelBlue;
            this.BTN_User.Location = new System.Drawing.Point(0, 482);
            this.BTN_User.Margin = new System.Windows.Forms.Padding(2);
            this.BTN_User.Name = "BTN_User";
            this.BTN_User.Size = new System.Drawing.Size(188, 57);
            this.BTN_User.TabIndex = 2;
            this.BTN_User.Text = "User ";
            this.BTN_User.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BTN_User.UseVisualStyleBackColor = false;
            this.BTN_User.Click += new System.EventHandler(this.BTN_UM_Click);
            // 
            // BTN_ApartmentReport
            // 
            this.BTN_ApartmentReport.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.BTN_ApartmentReport.Dock = System.Windows.Forms.DockStyle.Top;
            this.BTN_ApartmentReport.FlatAppearance.BorderSize = 0;
            this.BTN_ApartmentReport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTN_ApartmentReport.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_ApartmentReport.ForeColor = System.Drawing.Color.SteelBlue;
            this.BTN_ApartmentReport.Location = new System.Drawing.Point(0, 425);
            this.BTN_ApartmentReport.Margin = new System.Windows.Forms.Padding(2);
            this.BTN_ApartmentReport.Name = "BTN_ApartmentReport";
            this.BTN_ApartmentReport.Size = new System.Drawing.Size(188, 57);
            this.BTN_ApartmentReport.TabIndex = 2;
            this.BTN_ApartmentReport.Text = "Apartment Reoprt ";
            this.BTN_ApartmentReport.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BTN_ApartmentReport.UseVisualStyleBackColor = false;
            this.BTN_ApartmentReport.Click += new System.EventHandler(this.Txt_FullApartmentReport_Click);
            // 
            // pnlnav
            // 
            this.pnlnav.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.pnlnav.Location = new System.Drawing.Point(0, 157);
            this.pnlnav.Margin = new System.Windows.Forms.Padding(2);
            this.pnlnav.Name = "pnlnav";
            this.pnlnav.Size = new System.Drawing.Size(2, 81);
            this.pnlnav.TabIndex = 2;
            // 
            // BTN_LOGOUT
            // 
            this.BTN_LOGOUT.BackColor = System.Drawing.Color.Maroon;
            this.BTN_LOGOUT.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.BTN_LOGOUT.FlatAppearance.BorderSize = 0;
            this.BTN_LOGOUT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTN_LOGOUT.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_LOGOUT.ForeColor = System.Drawing.Color.White;
            this.BTN_LOGOUT.Location = new System.Drawing.Point(0, 596);
            this.BTN_LOGOUT.Margin = new System.Windows.Forms.Padding(2);
            this.BTN_LOGOUT.Name = "BTN_LOGOUT";
            this.BTN_LOGOUT.Size = new System.Drawing.Size(188, 44);
            this.BTN_LOGOUT.TabIndex = 1;
            this.BTN_LOGOUT.Text = "LOGOUT";
            this.BTN_LOGOUT.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BTN_LOGOUT.UseVisualStyleBackColor = false;
            this.BTN_LOGOUT.Click += new System.EventHandler(this.BTN_LOGOUT_Click);
            // 
            // BTN_Request
            // 
            this.BTN_Request.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.BTN_Request.Dock = System.Windows.Forms.DockStyle.Top;
            this.BTN_Request.FlatAppearance.BorderSize = 0;
            this.BTN_Request.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTN_Request.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_Request.ForeColor = System.Drawing.Color.SteelBlue;
            this.BTN_Request.Location = new System.Drawing.Point(0, 359);
            this.BTN_Request.Margin = new System.Windows.Forms.Padding(2);
            this.BTN_Request.Name = "BTN_Request";
            this.BTN_Request.Size = new System.Drawing.Size(188, 66);
            this.BTN_Request.TabIndex = 1;
            this.BTN_Request.Text = "Lease Extension Request";
            this.BTN_Request.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BTN_Request.UseVisualStyleBackColor = false;
            this.BTN_Request.Click += new System.EventHandler(this.BTN_MLER_Click);
            // 
            // BTN_Customer
            // 
            this.BTN_Customer.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.BTN_Customer.Dock = System.Windows.Forms.DockStyle.Top;
            this.BTN_Customer.FlatAppearance.BorderSize = 0;
            this.BTN_Customer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTN_Customer.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_Customer.ForeColor = System.Drawing.Color.SteelBlue;
            this.BTN_Customer.Location = new System.Drawing.Point(0, 302);
            this.BTN_Customer.Margin = new System.Windows.Forms.Padding(2);
            this.BTN_Customer.Name = "BTN_Customer";
            this.BTN_Customer.Size = new System.Drawing.Size(188, 57);
            this.BTN_Customer.TabIndex = 1;
            this.BTN_Customer.Text = "Customer ";
            this.BTN_Customer.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BTN_Customer.UseVisualStyleBackColor = false;
            this.BTN_Customer.Click += new System.EventHandler(this.BTN_MCD_Click);
            // 
            // BTN_Lease
            // 
            this.BTN_Lease.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.BTN_Lease.Dock = System.Windows.Forms.DockStyle.Top;
            this.BTN_Lease.FlatAppearance.BorderSize = 0;
            this.BTN_Lease.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTN_Lease.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_Lease.ForeColor = System.Drawing.Color.SteelBlue;
            this.BTN_Lease.Location = new System.Drawing.Point(0, 245);
            this.BTN_Lease.Margin = new System.Windows.Forms.Padding(2);
            this.BTN_Lease.Name = "BTN_Lease";
            this.BTN_Lease.Size = new System.Drawing.Size(188, 57);
            this.BTN_Lease.TabIndex = 1;
            this.BTN_Lease.Text = "Lease ";
            this.BTN_Lease.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BTN_Lease.UseVisualStyleBackColor = false;
            this.BTN_Lease.Click += new System.EventHandler(this.BTN_ADLD_Click);
            // 
            // BTN_Apartment
            // 
            this.BTN_Apartment.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.BTN_Apartment.Dock = System.Windows.Forms.DockStyle.Top;
            this.BTN_Apartment.FlatAppearance.BorderSize = 0;
            this.BTN_Apartment.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTN_Apartment.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_Apartment.ForeColor = System.Drawing.Color.SteelBlue;
            this.BTN_Apartment.Location = new System.Drawing.Point(0, 188);
            this.BTN_Apartment.Margin = new System.Windows.Forms.Padding(2);
            this.BTN_Apartment.Name = "BTN_Apartment";
            this.BTN_Apartment.Size = new System.Drawing.Size(188, 57);
            this.BTN_Apartment.TabIndex = 1;
            this.BTN_Apartment.Text = "Apartment ";
            this.BTN_Apartment.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BTN_Apartment.UseVisualStyleBackColor = false;
            this.BTN_Apartment.Click += new System.EventHandler(this.BTN_MAD_Click);
            // 
            // BTN_Dashboard
            // 
            this.BTN_Dashboard.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.BTN_Dashboard.Dock = System.Windows.Forms.DockStyle.Top;
            this.BTN_Dashboard.FlatAppearance.BorderSize = 0;
            this.BTN_Dashboard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTN_Dashboard.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_Dashboard.ForeColor = System.Drawing.Color.SteelBlue;
            this.BTN_Dashboard.Location = new System.Drawing.Point(0, 131);
            this.BTN_Dashboard.Margin = new System.Windows.Forms.Padding(2);
            this.BTN_Dashboard.Name = "BTN_Dashboard";
            this.BTN_Dashboard.Size = new System.Drawing.Size(188, 57);
            this.BTN_Dashboard.TabIndex = 1;
            this.BTN_Dashboard.Text = "Dashboard";
            this.BTN_Dashboard.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BTN_Dashboard.UseVisualStyleBackColor = false;
            this.BTN_Dashboard.Click += new System.EventHandler(this.BTN_Dashboard_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(188, 131);
            this.panel2.TabIndex = 1;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(188, 131);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.PictureBox1_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.SteelBlue;
            this.panel3.Controls.Add(this.lblHead);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(188, 0);
            this.panel3.Margin = new System.Windows.Forms.Padding(2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(852, 81);
            this.panel3.TabIndex = 1;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // lblHead
            // 
            this.lblHead.AutoSize = true;
            this.lblHead.Font = new System.Drawing.Font("Arial Narrow", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHead.ForeColor = System.Drawing.Color.White;
            this.lblHead.Location = new System.Drawing.Point(414, 28);
            this.lblHead.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblHead.Name = "lblHead";
            this.lblHead.Size = new System.Drawing.Size(131, 31);
            this.lblHead.TabIndex = 0;
            this.lblHead.Text = "Dashboard";
            this.lblHead.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnl_Main
            // 
            this.pnl_Main.AutoSize = true;
            this.pnl_Main.BackColor = System.Drawing.Color.LightSteelBlue;
            this.pnl_Main.Location = new System.Drawing.Point(188, 81);
            this.pnl_Main.Margin = new System.Windows.Forms.Padding(2);
            this.pnl_Main.Name = "pnl_Main";
            this.pnl_Main.Size = new System.Drawing.Size(850, 559);
            this.pnl_Main.TabIndex = 2;
            this.pnl_Main.Paint += new System.Windows.Forms.PaintEventHandler(this.Pnl_Main_Paint);
            // 
            // AdminDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.ClientSize = new System.Drawing.Size(1040, 640);
            this.Controls.Add(this.pnl_Main);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "AdminDashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AdminDashboard";
            this.Load += new System.EventHandler(this.AdminDashboard_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button BTN_LOGOUT;
        private System.Windows.Forms.Button BTN_Customer;
        private System.Windows.Forms.Button BTN_Apartment;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel pnlnav;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel pnl_Main;
        private System.Windows.Forms.Label lblHead;
        private System.Windows.Forms.Button BTN_User;
        private System.Windows.Forms.Button BTN_Request;
        private System.Windows.Forms.Button BTN_Lease;
        private System.Windows.Forms.Button BTN_Dashboard;
        private System.Windows.Forms.Button BTN_Maintenance;
        private System.Windows.Forms.Button BTN_ApartmentReport;
    }
}