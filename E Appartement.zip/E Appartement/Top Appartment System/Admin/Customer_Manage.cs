﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace E_Appartment.Admin
{
    public partial class Customer_Manage : Form
    {

        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-PBEM3OT\SQLEXPRESS;Initial Catalog=Top_Appartment;Integrated Security=True");

        public Customer_Manage()
        {
            InitializeComponent();
        }

        private void Customer_Manage_Load(object sender, EventArgs e)
        {
            load();
        }
        void load()
        {
            try
            {
                con.Open();
                string sql = "select * from Customer_Manage;";
                SqlDataAdapter adapter = new SqlDataAdapter(sql, con);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dataGridView_Customer.DataSource = dt;
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void Btn_save_Click(object sender, EventArgs e)
        {
            if (txt_customerID.Text == "" || txt_customerName.Text == ""|| txt_Address.Text == "" || txt_PhoneNumber.Text == "" || txt_mail.Text == "" || txt_NIC.Text == "")
            {
                MessageBox.Show("Fill all field");//Show Message if field is not filled 
            }
            else
            {
                try// Exception Handler
                {
                    con.Open();
                    string q1 = "insert into Customer_Manage values ('" + txt_customerID.Text + "','" + txt_customerName.Text + "','" + txt_Address.Text + "','" + txt_PhoneNumber.Text + "','" + txt_mail.Text + "','" + txt_NIC.Text + "');";
                    SqlCommand comd1 = new SqlCommand(q1, con);
                    int i = comd1.ExecuteNonQuery();
                    con.Close();

                    if (i > 0)
                    {
                        load();
                        MessageBox.Show("Insert successfully", "information", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    }
                    else
                    {
                        MessageBox.Show("Error", "alert", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                    con.Close();
                }


            }
        }

        private void Btn_clear_Click(object sender, EventArgs e)
        {
            txt_customerID.Text = "";
            txt_customerName.Clear();
            txt_Address.Clear();
            txt_PhoneNumber.Clear();
            txt_mail.Clear();
            txt_NIC.Clear();

            btn_update.Enabled = false;
            btn_delete.Enabled = false;
            txt_customerID.Enabled = true;
        }

        private void Btn_delete_Click(object sender, EventArgs e)
        {
            if (txt_customerID.Text == "")
            {
                MessageBox.Show("fill all field");
            }
            else
            {
                try
                {
                    con.Open();
                    string q1 = "delete Customer_Manage where CustomerID = '" + txt_customerID.Text + "'";
                    SqlCommand comd1 = new SqlCommand(q1, con);
                    int i = comd1.ExecuteNonQuery();
                    con.Close();

                    if (i > 0)
                    {
                        MessageBox.Show("delete successfully", "information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        load();
                        btn_update.Enabled = false;
                        btn_delete.Enabled = false;
                        txt_customerID.Enabled = true;
                    }
                    else
                    {
                        MessageBox.Show("Error", "alert", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }


            }
        }

        private void DataGridView_Customer_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {

                txt_customerID.Text = dataGridView_Customer.Rows[e.RowIndex].Cells[0].Value.ToString();
                txt_customerName.Text = dataGridView_Customer.Rows[e.RowIndex].Cells[1].Value.ToString();
                txt_Address.Text = dataGridView_Customer.Rows[e.RowIndex].Cells[2].Value.ToString();
                txt_PhoneNumber.Text = dataGridView_Customer.Rows[e.RowIndex].Cells[3].Value.ToString();
                txt_mail.Text = dataGridView_Customer.Rows[e.RowIndex].Cells[4].Value.ToString();
                txt_NIC.Text = dataGridView_Customer.Rows[e.RowIndex].Cells[5].Value.ToString();

                btn_update.Enabled = true;
                btn_delete.Enabled = true;

                txt_customerID.Enabled = false;
            }
        }

        private void Btn_update_Click(object sender, EventArgs e)
        {
            if (txt_customerID.Text == "")
            {
                MessageBox.Show("fill all field");
            }
            else
            {
                try
                {
                    con.Open();
                    string q2 = " update Customer_Manage set CustomerName='" + txt_customerName.Text + "',Address='" + txt_Address.Text + "',phoneNumber='" + txt_PhoneNumber.Text + "',mail='" + txt_mail.Text + "',NIC='" + txt_NIC.Text + "' where CustomerID='" + txt_customerID.Text + "';";
                    SqlCommand comd2 = new SqlCommand(q2, con);
                    int i = comd2.ExecuteNonQuery();
                    con.Close();

                    if (i > 0)
                    {

                        MessageBox.Show("update successfully", "information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        load();
                        btn_update.Enabled = false;
                        btn_delete.Enabled = false;
                        txt_customerID.Enabled = true;
                    }
                    else
                    {
                        MessageBox.Show("Error", "alert", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                    con.Close();
                }
            }
        }
    }
}
