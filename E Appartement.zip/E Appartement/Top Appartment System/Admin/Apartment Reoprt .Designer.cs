﻿namespace E_Appartment.Admin
{
    partial class Full_Apartment_Reoprt
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dataGridView_Apartment = new System.Windows.Forms.DataGridView();
            this.e_AppartmentDataSet = new E_Appartment.E_AppartmentDataSet();
            this.btn_save = new System.Windows.Forms.Button();
            this.apartment_ManageTableAdapter = new E_Appartment.E_AppartmentDataSetTableAdapters.Apartment_ManageTableAdapter();
            this.apartmentManageBindingSource = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Apartment)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.e_AppartmentDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.apartmentManageBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView_Apartment
            // 
            this.dataGridView_Apartment.AllowUserToAddRows = false;
            this.dataGridView_Apartment.AllowUserToDeleteRows = false;
            this.dataGridView_Apartment.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_Apartment.BackgroundColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Magenta;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Perpetua Titling MT", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.Padding = new System.Windows.Forms.Padding(0, 10, 0, 10);
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Orchid;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_Apartment.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView_Apartment.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_Apartment.Cursor = System.Windows.Forms.Cursors.Cross;
            this.dataGridView_Apartment.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnF2;
            this.dataGridView_Apartment.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dataGridView_Apartment.Location = new System.Drawing.Point(29, 29);
            this.dataGridView_Apartment.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridView_Apartment.Name = "dataGridView_Apartment";
            this.dataGridView_Apartment.ReadOnly = true;
            this.dataGridView_Apartment.RowHeadersVisible = false;
            this.dataGridView_Apartment.RowHeadersWidth = 51;
            this.dataGridView_Apartment.RowTemplate.Height = 28;
            this.dataGridView_Apartment.ShowEditingIcon = false;
            this.dataGridView_Apartment.Size = new System.Drawing.Size(799, 394);
            this.dataGridView_Apartment.TabIndex = 153;
            this.dataGridView_Apartment.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataGridView_Apartment_CellContentClick);
            // 
            // e_AppartmentDataSet
            // 
            this.e_AppartmentDataSet.DataSetName = "E_AppartmentDataSet";
            this.e_AppartmentDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // btn_save
            // 
            this.btn_save.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_save.ForeColor = System.Drawing.Color.Black;
            this.btn_save.Location = new System.Drawing.Point(677, 441);
            this.btn_save.Margin = new System.Windows.Forms.Padding(2);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(151, 31);
            this.btn_save.TabIndex = 154;
            this.btn_save.Text = "Export ";
            this.btn_save.UseVisualStyleBackColor = true;
            this.btn_save.Click += new System.EventHandler(this.Btn_save_Click);
            // 
            // apartment_ManageTableAdapter
            // 
            this.apartment_ManageTableAdapter.ClearBeforeFill = true;
            // 
            // apartmentManageBindingSource
            // 
            this.apartmentManageBindingSource.DataMember = "Apartment_Manage";
            this.apartmentManageBindingSource.DataSource = this.e_AppartmentDataSet;
            // 
            // Full_Apartment_Reoprt
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(975, 609);
            this.Controls.Add(this.btn_save);
            this.Controls.Add(this.dataGridView_Apartment);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Full_Apartment_Reoprt";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Full_Apartment_Reoprt";
            this.Load += new System.EventHandler(this.Full_Apartment_Reoprt_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Apartment)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.e_AppartmentDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.apartmentManageBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.DataGridView dataGridView_Apartment;
        private System.Windows.Forms.Button btn_save;
        private E_AppartmentDataSet e_AppartmentDataSet;
        private E_AppartmentDataSetTableAdapters.Apartment_ManageTableAdapter apartment_ManageTableAdapter;
        private System.Windows.Forms.BindingSource apartmentManageBindingSource;
    }
}