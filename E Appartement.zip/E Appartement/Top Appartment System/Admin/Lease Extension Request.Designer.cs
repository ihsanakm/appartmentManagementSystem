﻿namespace E_Appartment.Admin
{
    partial class Lease_Extension_Request
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dataGridView_Admin_Lease_Extension_Request = new System.Windows.Forms.DataGridView();
            this.ID = new System.Windows.Forms.Label();
            this.btn_Decline = new System.Windows.Forms.Button();
            this.Btn_Accept = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Admin_Lease_Extension_Request)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView_Admin_Lease_Extension_Request
            // 
            this.dataGridView_Admin_Lease_Extension_Request.AllowUserToAddRows = false;
            this.dataGridView_Admin_Lease_Extension_Request.AllowUserToDeleteRows = false;
            this.dataGridView_Admin_Lease_Extension_Request.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_Admin_Lease_Extension_Request.BackgroundColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Magenta;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Perpetua Titling MT", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.Padding = new System.Windows.Forms.Padding(0, 10, 0, 10);
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Orchid;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_Admin_Lease_Extension_Request.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView_Admin_Lease_Extension_Request.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_Admin_Lease_Extension_Request.Cursor = System.Windows.Forms.Cursors.Cross;
            this.dataGridView_Admin_Lease_Extension_Request.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dataGridView_Admin_Lease_Extension_Request.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnF2;
            this.dataGridView_Admin_Lease_Extension_Request.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dataGridView_Admin_Lease_Extension_Request.Location = new System.Drawing.Point(0, 123);
            this.dataGridView_Admin_Lease_Extension_Request.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridView_Admin_Lease_Extension_Request.Name = "dataGridView_Admin_Lease_Extension_Request";
            this.dataGridView_Admin_Lease_Extension_Request.ReadOnly = true;
            this.dataGridView_Admin_Lease_Extension_Request.RowHeadersVisible = false;
            this.dataGridView_Admin_Lease_Extension_Request.RowHeadersWidth = 51;
            this.dataGridView_Admin_Lease_Extension_Request.RowTemplate.Height = 28;
            this.dataGridView_Admin_Lease_Extension_Request.ShowEditingIcon = false;
            this.dataGridView_Admin_Lease_Extension_Request.Size = new System.Drawing.Size(850, 486);
            this.dataGridView_Admin_Lease_Extension_Request.TabIndex = 136;
            this.dataGridView_Admin_Lease_Extension_Request.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataGridView_Admin_Lease_Extension_Request_CellContentClick);
            this.dataGridView_Admin_Lease_Extension_Request.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataGridView_Admin_Lease_Extension_Request_CellContentDoubleClick);
            // 
            // ID
            // 
            this.ID.AutoSize = true;
            this.ID.Font = new System.Drawing.Font("Arial Narrow", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ID.ForeColor = System.Drawing.Color.SteelBlue;
            this.ID.Location = new System.Drawing.Point(264, 20);
            this.ID.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ID.Name = "ID";
            this.ID.Size = new System.Drawing.Size(281, 31);
            this.ID.TabIndex = 137;
            this.ID.Text = "Lease Extension Request";
            // 
            // btn_Decline
            // 
            this.btn_Decline.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_Decline.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Decline.ForeColor = System.Drawing.Color.DarkRed;
            this.btn_Decline.Location = new System.Drawing.Point(707, 14);
            this.btn_Decline.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Decline.Name = "btn_Decline";
            this.btn_Decline.Size = new System.Drawing.Size(95, 37);
            this.btn_Decline.TabIndex = 156;
            this.btn_Decline.Text = "Decline";
            this.btn_Decline.UseVisualStyleBackColor = false;
            this.btn_Decline.Click += new System.EventHandler(this.Btn_Decline_Click);
            // 
            // Btn_Accept
            // 
            this.Btn_Accept.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.Btn_Accept.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Accept.ForeColor = System.Drawing.Color.Green;
            this.Btn_Accept.Location = new System.Drawing.Point(578, 14);
            this.Btn_Accept.Margin = new System.Windows.Forms.Padding(2);
            this.Btn_Accept.Name = "Btn_Accept";
            this.Btn_Accept.Size = new System.Drawing.Size(101, 37);
            this.Btn_Accept.TabIndex = 157;
            this.Btn_Accept.Text = "Accept";
            this.Btn_Accept.UseVisualStyleBackColor = false;
            this.Btn_Accept.Click += new System.EventHandler(this.Btn_Accept_Click);
            // 
            // Lease_Extension_Request
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(850, 609);
            this.Controls.Add(this.Btn_Accept);
            this.Controls.Add(this.btn_Decline);
            this.Controls.Add(this.ID);
            this.Controls.Add(this.dataGridView_Admin_Lease_Extension_Request);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Lease_Extension_Request";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Lease_Extension_Request";
            this.Load += new System.EventHandler(this.Lease_Extension_Request_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Admin_Lease_Extension_Request)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView dataGridView_Admin_Lease_Extension_Request;
        private System.Windows.Forms.Label ID;
        private System.Windows.Forms.Button btn_Decline;
        private System.Windows.Forms.Button Btn_Accept;
    }
}