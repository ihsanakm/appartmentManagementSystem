﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace E_Appartment.Admin
{
    public partial class Apartment : Form
    {

        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-PBEM3OT\SQLEXPRESS;Initial Catalog=Top_Appartment;Integrated Security=True");

        public Apartment()
        {
            InitializeComponent();
        }

        private void ComboBox_Status_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void Apartment_Load(object sender, EventArgs e)
        {
            load();
            
        }

        void load()
        {

            try //Exception Handler
            {
                con.Open();
                string sql = "select * from Apartment_Manage;"; //Select Query
                SqlDataAdapter adapter = new SqlDataAdapter(sql, con);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dataGridView_Apartment.DataSource = dt;//Assing Data to Datagridview
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void Btn_save_Click(object sender, EventArgs e)
        {

            if (ValidateChildren(ValidationConstraints.Enabled))
            {
                
            }

            if (txt_ApartmentID.Text == "" || comboBox_Type.Text == "" || txt_address.Text == "" || txt_Rent.Text == "" || txt_DateofOccupancy.Text == "" || comboBox_Status.Text == "")
            {
                MessageBox.Show("Fill all field");
            }
            else
            {
                try
                {
                    con.Open();
                    string DateofOccupancy = txt_DateofOccupancy.Value.ToString("yyyy/MM/dd");
                    string q1 = "insert into Apartment_Manage values ('" + txt_ApartmentID.Text + "','" + comboBox_Type.Text + "','" + txt_address.Text + "','" + txt_Rent.Text + "','" + DateofOccupancy + "','" + comboBox_Status.Text + "');";
                    ///MessageBox.Show(q1);
                    SqlCommand comd1 = new SqlCommand(q1, con);
                    int i = comd1.ExecuteNonQuery();
                    con.Close();

                    if (i > 0)
                    {
                        load();
                        MessageBox.Show("Insert successfully", "information", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        txt_ApartmentID.Text = "";
                        comboBox_Type.ResetText();
                        txt_address.Clear();
                        txt_Rent.Clear();
                        txt_DateofOccupancy.ResetText();
                        comboBox_Status.ResetText();
                    }
                    else
                    {
                        MessageBox.Show("Error", "alert", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                    con.Close();
                }


            }

        }

        private void Btn_clear_Click(object sender, EventArgs e)
        {
            txt_ApartmentID.Text = "";
            comboBox_Type.Items.Clear();
            txt_address.Clear();
            txt_Rent.Clear();
            txt_DateofOccupancy.ResetText();
            comboBox_Status.Items.Clear();

            btn_update.Enabled = false;
            btn_delete.Enabled = false;
            txt_ApartmentID.Enabled = true;

        }

        private void Btn_delete_Click(object sender, EventArgs e)
        {

            if (txt_ApartmentID.Text == "")
            {
                MessageBox.Show("fill all field");
            }
            else
            {
                try
                {
                    con.Open();
                    string DateofOccupancy = txt_DateofOccupancy.Value.ToString("yyyy/MM/dd");
                    string q1 = "delete Apartment_Manage  where ApartmentID = '" + txt_ApartmentID.Text + "'";
                    SqlCommand comd1 = new SqlCommand(q1, con);
                    int i = comd1.ExecuteNonQuery();
                    con.Close();

                    if (i > 0)
                    {
                        MessageBox.Show("Deleted Successfully", "information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        load();
                        btn_update.Enabled = false;
                        btn_delete.Enabled = false;
                        txt_ApartmentID.Enabled = true;
                    }
                    else
                    {
                        MessageBox.Show("Error", "alert", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }


            }


        }

        private void DataGridView_Apartment_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {

                txt_ApartmentID.Text = dataGridView_Apartment.Rows[e.RowIndex].Cells[0].Value.ToString();
                comboBox_Type.Text = dataGridView_Apartment.Rows[e.RowIndex].Cells[1].Value.ToString();
                txt_address.Text = dataGridView_Apartment.Rows[e.RowIndex].Cells[2].Value.ToString();
                txt_Rent.Text = dataGridView_Apartment.Rows[e.RowIndex].Cells[3].Value.ToString();
                txt_DateofOccupancy.Text = dataGridView_Apartment.Rows[e.RowIndex].Cells[4].Value.ToString();
                comboBox_Status.Text = dataGridView_Apartment.Rows[e.RowIndex].Cells[5].Value.ToString();

                btn_update.Enabled = true;
                btn_delete.Enabled = true;

                txt_ApartmentID.Enabled = false;
            }
        }

        private void Btn_update_Click(object sender, EventArgs e)
        {


            if (txt_ApartmentID.Text == "")
            {
                MessageBox.Show("fill all field");
            }
            else
            {
                try
                {
                    con.Open();
                    string DateofOccupancy = txt_DateofOccupancy.Value.ToString("yyyy/MM/dd");
                    string q2 = " update Apartment_Manage set Type='" + comboBox_Type.Text + "',Address='" + txt_address.Text + "',Rent='" + txt_Rent.Text + "',DateofOccupancy='" + DateofOccupancy + "',Status='" + comboBox_Status.Text + "'where ApartmentID='" + txt_ApartmentID.Text + "';";
                    SqlCommand comd2 = new SqlCommand(q2, con);
                    int i = comd2.ExecuteNonQuery();
                    con.Close();

                    if (i > 0)
                    {

                        MessageBox.Show("update successfully", "information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        load();
                        btn_update.Enabled = false;
                        btn_delete.Enabled = false;
                        txt_ApartmentID.Enabled = true;
                    }
                    else
                    {
                        MessageBox.Show("Error", "alert", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                    con.Close();
                }
            }

        }

        private void txt_ApartmentID_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txt_ApartmentID.Text))
            {
                e.Cancel = true;
                txt_ApartmentID.Focus();
                errorProvider1.SetError(txt_ApartmentID, "Fill blank!");
            }
            else
            {
                e.Cancel = false;
                errorProvider1.SetError(txt_ApartmentID, "");
            }
        }

        private void txt_address_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txt_address.Text))
            {
                e.Cancel = true;
                txt_address.Focus();
                errorProvider1.SetError(txt_address, "Fill blank!");
            }
            else
            {
                e.Cancel = false;
                errorProvider1.SetError(txt_address, "");
            }
        }

        private void txt_Rent_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txt_Rent.Text))
            {
                e.Cancel = true;
                txt_Rent.Focus();
                errorProvider1.SetError(txt_Rent, "Fill blank!");
            }
            else
            {
                e.Cancel = false;
                errorProvider1.SetError(txt_Rent, "");
            }
        }

        private void comboBox_Status_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(comboBox_Status.Text))
            {
                e.Cancel = true;
                comboBox_Status.Focus();
                errorProvider1.SetError(comboBox_Status, "Select One");
            }
            else
            {
                e.Cancel = false;
                errorProvider1.SetError(comboBox_Status, "");
            }
        }

        private void comboBox_Type_Validating(object sender, CancelEventArgs e)
        {

            if (string.IsNullOrWhiteSpace(comboBox_Type.Text))
            {
                e.Cancel = true;
                comboBox_Type.Focus();
                errorProvider1.SetError(comboBox_Type, "Select One");
            }
            else
            {
                e.Cancel = false;
                errorProvider1.SetError(comboBox_Type, "");
            }
        }
    }
}
