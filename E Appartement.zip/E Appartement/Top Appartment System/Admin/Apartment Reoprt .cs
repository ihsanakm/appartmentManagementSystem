﻿using iTextSharp.text.pdf;
using iTextSharp.text;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace E_Appartment.Admin
{
    public partial class Full_Apartment_Reoprt : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-PBEM3OT\SQLEXPRESS;Initial Catalog=Top_Appartment;Integrated Security=True");


        public Full_Apartment_Reoprt()
        {
            InitializeComponent();
        }

        private void Full_Apartment_Reoprt_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'e_AppartmentDataSet.Apartment_Manage' table. You can move, or remove it, as needed.
           /// this.apartment_ManageTableAdapter.Fill(this.e_AppartmentDataSet.Apartment_Manage);
            load();
        }

        void load()
        {
            try
            {
                SqlConnection sqlCon;
                string conString = null;
                string sqlQuery = null;

                conString = "Data Source=DESKTOP-PBEM3OT\\SQLEXPRESS;Initial Catalog=Top_Appartment;Integrated Security=True";
                sqlCon = new SqlConnection(conString);
                sqlCon.Open();
                sqlQuery = "SELECT * FROM Apartment_Manage";
                SqlDataAdapter dscmd = new SqlDataAdapter(sqlQuery, sqlCon);
                DataTable dtData = new DataTable();
                dscmd.Fill(dtData);
                dataGridView_Apartment.DataSource = dtData;
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void Btn_save_Click(object sender, EventArgs e)
        {

            if (dataGridView_Apartment.Rows.Count > 0)
            {
                SaveFileDialog sfd = new SaveFileDialog();  //Exporting Data into PDF file
                sfd.Filter = "PDF (*.pdf)|*.pdf";
                sfd.FileName = "Output.pdf";
                bool fileError = false;
                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    if (File.Exists(sfd.FileName))
                    {
                        try
                        {
                            File.Delete(sfd.FileName);
                        }
                        catch (IOException ex)
                        {
                            fileError = true;
                            MessageBox.Show("It wasn't possible to write the data to the disk." + ex.Message);
                        }
                    }
                    if (!fileError)
                    {
                        try
                        {
                            PdfPTable pdfTable = new PdfPTable(dataGridView_Apartment.Columns.Count);
                            pdfTable.DefaultCell.Padding = 3;
                            pdfTable.WidthPercentage = 100;
                            pdfTable.HorizontalAlignment = Element.ALIGN_LEFT;

                            foreach (DataGridViewColumn column in dataGridView_Apartment.Columns)
                            {
                                PdfPCell cell = new PdfPCell(new Phrase(column.HeaderText));
                                pdfTable.AddCell(cell);
                            }

                            foreach (DataGridViewRow row in dataGridView_Apartment.Rows)
                            {
                                foreach (DataGridViewCell cell in row.Cells)
                                {
                                    pdfTable.AddCell(cell.Value.ToString());
                                }
                            }

                            using (FileStream stream = new FileStream(sfd.FileName, FileMode.Create))
                            {
                                Document pdfDoc = new Document(PageSize.A4, 10f, 20f, 20f, 10f);
                                PdfWriter.GetInstance(pdfDoc, stream);
                                pdfDoc.Open();
                                pdfDoc.Add(pdfTable);
                                pdfDoc.Close();
                                stream.Close();
                            }

                            MessageBox.Show("Data Exported Successfully !!!", "Info");
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error :" + ex.Message);
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("No Record To Export !!!", "Info");
            }
            /* if (dataGridView_Apartment.Rows.Count > 0)
            {
                Microsoft.Office.Interop.Excel._Application app = new Microsoft.Office.Interop.Excel.Application();
                Microsoft.Office.Interop.Excel._Workbook workbook = app.Workbooks.Add(Type.Missing);
                Microsoft.Office.Interop.Excel._Worksheet worksheet = null;

                app.Visible = true;

                worksheet = workbook.Sheets["Sheet1"];
                worksheet = workbook.ActiveSheet;
                worksheet.Name = "Sales";
                for (int i = 1; i < dataGridView_Apartment.Columns.Count + 1; i++)
                {
                    worksheet.Cells[1, i] = dataGridView_Apartment.Columns[i - 1].HeaderText;
                }
                for (int i = 0; i < dataGridView_Apartment.Rows.Count; i++)
                {
                    for (int j = 0; j < dataGridView_Apartment.Columns.Count; j++)
                    {
                        worksheet.Cells[i + 2, j + 1] = dataGridView_Apartment.Rows[i].Cells[j].Value.ToString();
                    }
                }

                app.Quit();
            }*/
        }


        private void Button1_Click(object sender, EventArgs e)
        {

        }

        private void DataGridView_Apartment_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
