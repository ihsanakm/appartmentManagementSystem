﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace E_Appartment
{
    public partial class AdminDashboard : Form
    {

        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]

        private static extern IntPtr CreateRoundRectRgn

    (

    int nLeftRect,
    int nTopRect,
    int nRightRect,
    int nBottomRect,
    int nWidthEllipse,
    int nHeightEllipse

    );

        public AdminDashboard()
        {
            InitializeComponent();
            Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, Width, Height, 25, 25));
            pnlnav.Height = BTN_Dashboard.Height;
            pnlnav.Top = BTN_Dashboard.Top;
            pnlnav.Left = BTN_Dashboard.Left;
            BTN_Dashboard.BackColor = Color.FromArgb(46, 51, 73);
        }

        public void LoadForms(object Forms)
        {
            if (this.pnl_Main.Controls.Count > 0)
                this.pnl_Main.Controls.RemoveAt(0);
            Form f = Forms as Form;
            f.TopLevel = false;
            f.Dock = DockStyle.Fill;
            this.pnl_Main.Controls.Add(f);
            this.pnl_Main.Tag = f;
            f.Show();
        }
        private void BTN_MAD_Click(object sender, EventArgs e)
        {
            BUTTONColor();

            pnlnav.Height = BTN_Apartment.Height;
            pnlnav.Top = BTN_Apartment.Top;
            pnlnav.Left = BTN_Apartment.Left;

            lblHead.Text = "Apartment";
            BTN_Apartment.BackColor = Color.FromArgb(46, 51, 73);

            LoadForms(new Admin.Apartment());
        }

        private void AdminDashboard_Load(object sender, EventArgs e)
        {

        }

        private void BTN_Dashboard_Click(object sender, EventArgs e)
        {
            BUTTONColor();

            pnlnav.Height = BTN_Dashboard.Height;
            pnlnav.Top = BTN_Dashboard.Top;
            pnlnav.Left = BTN_Dashboard.Left;

            lblHead.Text = "Dashboard";
            BTN_Dashboard.BackColor = Color.FromArgb(46, 51, 73);


            LoadForms(new Admin.Dashboard());
        }

        private void BTN_MCD_Click(object sender, EventArgs e)
        {
            BUTTONColor();

            pnlnav.Height = BTN_Customer.Height;
            pnlnav.Top = BTN_Customer.Top;
            pnlnav.Left = BTN_Customer.Left;

            lblHead.Text = "Customer";
            BTN_Customer.BackColor = Color.FromArgb(46, 51, 73);

            LoadForms(new Admin.Customer_Manage());
        }

        private void BTN_ADLD_Click(object sender, EventArgs e)
        {
            BUTTONColor();
            pnlnav.Height = BTN_Lease.Height;
            pnlnav.Top = BTN_Lease.Top;
            pnlnav.Left = BTN_Lease.Left;

            lblHead.Text = "Lease";
            BTN_Lease.BackColor = Color.FromArgb(46, 51, 73);

            LoadForms(new Admin.Lease());
        }

        private void BTN_Maintenance_Click(object sender, EventArgs e)
        {
            BUTTONColor();
            pnlnav.Height = BTN_Maintenance.Height;
            pnlnav.Top = BTN_Maintenance.Top;
            pnlnav.Left = BTN_Maintenance.Left;

            lblHead.Text = "Maintenance";
            BTN_Maintenance.BackColor = Color.FromArgb(46, 51, 73);

            LoadForms(new Admin.Maintenance());
        }

        private void BTN_Maintenance_Click_1(object sender, EventArgs e)
        {

            BUTTONColor();
            pnlnav.Height = BTN_Maintenance.Height;
            pnlnav.Top = BTN_Maintenance.Top;
            pnlnav.Left = BTN_Maintenance.Left;

            lblHead.Text = "Maintenance";
            BTN_Maintenance.BackColor = Color.FromArgb(46, 51, 73);

            LoadForms(new Admin.Maintenance());

        }

        private void BTN_MLER_Click(object sender, EventArgs e)
        {
            BUTTONColor();
            pnlnav.Height = BTN_Request.Height;
            pnlnav.Top = BTN_Request.Top;
            pnlnav.Left = BTN_Request.Left;

            lblHead.Text = "Request";
            BTN_Request.BackColor = Color.FromArgb(46, 51, 73);

            LoadForms(new Admin.Lease_Extension_Request());
        }


        private void BTN_LOGOUT_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            this.Hide();
            login.Show();
        }

        private void BTN_UM_Click(object sender, EventArgs e)
        {
            BUTTONColor();
            pnlnav.Height = BTN_User.Height;
            pnlnav.Top = BTN_User.Top;
            pnlnav.Left = BTN_User.Left;

            lblHead.Text = "User";
            BTN_User.BackColor = Color.FromArgb(46, 51, 73);

            LoadForms(new User_Manage());

        }

        private void BUTTONColor()
        {
            BTN_Dashboard.BackColor = Color.FromArgb(24, 30, 54);
            BTN_Customer.BackColor = Color.FromArgb(24, 30, 54);
            BTN_Apartment.BackColor = Color.FromArgb(24, 30, 54);
            BTN_Lease.BackColor = Color.FromArgb(24, 30, 54);
            BTN_ApartmentReport.BackColor = Color.FromArgb(24, 30, 54);
            BTN_User.BackColor = Color.FromArgb(24, 30, 54);
            BTN_Request.BackColor = Color.FromArgb(24, 30, 54);
            BTN_Maintenance.BackColor = Color.FromArgb(24, 30, 54);
        }

        private void Pnl_Main_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Txt_FullApartmentReport_Click(object sender, EventArgs e)
        {

            BUTTONColor();
            pnlnav.Height = BTN_ApartmentReport.Height;
            pnlnav.Top = BTN_ApartmentReport.Top;
            pnlnav.Left = BTN_ApartmentReport.Left;

            lblHead.Text = "Full Apartment Report";
            BTN_ApartmentReport.BackColor = Color.FromArgb(46, 51, 73);

            LoadForms(new Admin.Full_Apartment_Reoprt());

        }

        private void Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void PictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }
    }

}
