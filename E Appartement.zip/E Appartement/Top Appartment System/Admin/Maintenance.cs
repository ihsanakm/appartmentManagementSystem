﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace E_Appartment.Admin
{
    public partial class Maintenance : Form
    {


        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-PBEM3OT\SQLEXPRESS;Initial Catalog=Top_Appartment;Integrated Security=True");

        public Maintenance()
        {
            InitializeComponent();
        }


        private void Maintenance_Load(object sender, EventArgs e)
        {
            load();
        }

        void load()
        {
            try
            {
                con.Open();
                string sql = "select * from Maintenance_Manage;";
                SqlDataAdapter adapter = new SqlDataAdapter(sql, con);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dataGridView_Maintenance.DataSource = dt;
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void Btn_save_Click(object sender, EventArgs e)
        {

            if (txt_MaintenanceID.Text == "")
            {
                MessageBox.Show("fill all field");
            }
            else
            {
                try
                {
                    con.Open();
                    string StartDate = txt_StartDate.Value.ToString("yyyy/MM/dd");
                    string EndDate = txt_EndDate.Value.ToString("yyyy/MM/dd");
                    string q1 = "insert into  Maintenance_Manage values ('" + txt_MaintenanceID.Text + "','" + txt_ApartmentID.Text + "','" + txt_Description.Text + "','" + txt_AssignedTo.Text + "','" + StartDate + "','" + EndDate + "','" + txt_Status.Text + "');";
                    MessageBox.Show(q1);
                    SqlCommand comd1 = new SqlCommand(q1, con);
                    int i = comd1.ExecuteNonQuery();
                    con.Close();

                    if (i > 0)
                    {
                        load();
                        MessageBox.Show("Insert successfully", "information", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    }
                    else
                    {
                        MessageBox.Show("Error", "alert", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                    con.Close();
                }


            }
        }

        private void Btn_clear_Click(object sender, EventArgs e)/// Clear Text Fields
        {
            txt_MaintenanceID.Clear();
            txt_ApartmentID.Clear();
            txt_Description.Clear();
            txt_AssignedTo.Clear();
            txt_StartDate.ResetText();
            txt_EndDate.ResetText();
            txt_Status.Clear();

            btn_update.Enabled = false;
            btn_delete.Enabled = false;
            txt_MaintenanceID.Enabled = true;
        }

        private void Btn_delete_Click(object sender, EventArgs e)
        {
            if (txt_MaintenanceID.Text == "")
            {
                MessageBox.Show("fill all field");
            }
            else
            {
                try
                {
                    con.Open();
                    string StartDate = txt_StartDate.Value.ToString("yyyy/MM/dd");
                    string EndDate = txt_EndDate.Value.ToString("yyyy/MM/dd");
                    string q1 = "delete Maintenance_Manage  where MaintenanceID = '" + txt_MaintenanceID.Text + "'";
                    SqlCommand comd1 = new SqlCommand(q1, con);
                    int i = comd1.ExecuteNonQuery();
                    con.Close();

                    if (i > 0)
                    {
                        MessageBox.Show("delete successfully", "information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        load();
                        btn_update.Enabled = false;
                        btn_delete.Enabled = false;
                        txt_MaintenanceID.Enabled = true;
                    }
                    else
                    {
                        MessageBox.Show("Error", "alert", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }


            }
        }

        private void DataGridView_Maintenance_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {

                txt_MaintenanceID.Text = dataGridView_Maintenance.Rows[e.RowIndex].Cells[0].Value.ToString();
                txt_ApartmentID.Text = dataGridView_Maintenance.Rows[e.RowIndex].Cells[1].Value.ToString();
                txt_Description.Text = dataGridView_Maintenance.Rows[e.RowIndex].Cells[2].Value.ToString();
                txt_AssignedTo.Text = dataGridView_Maintenance.Rows[e.RowIndex].Cells[3].Value.ToString();
                txt_StartDate.Text = dataGridView_Maintenance.Rows[e.RowIndex].Cells[4].Value.ToString();
                txt_EndDate.Text = dataGridView_Maintenance.Rows[e.RowIndex].Cells[5].Value.ToString();
                txt_Status.Text = dataGridView_Maintenance.Rows[e.RowIndex].Cells[6].Value.ToString();

                btn_update.Enabled = true;
                btn_delete.Enabled = true;

                txt_MaintenanceID.Enabled = false;
            }
        }

        private void Btn_update_Click(object sender, EventArgs e)
        {
            if (txt_MaintenanceID.Text == "")
            {
                MessageBox.Show("fill all field");
            }
            else
            {
                try
                {
                    con.Open();
                    string StartDate = txt_StartDate.Value.ToString("yyyy/MM/dd");
                    string EndDate = txt_EndDate.Value.ToString("yyyy/MM/dd");
                    string q2 = " update Maintenance_Manage set ApartmentID='" + txt_ApartmentID.Text + "',Description='" + txt_Description.Text + "',AssignedTo='" + txt_AssignedTo.Text + "',StartDate='" + StartDate + "',EandDate='" + EndDate + "',Status='" + txt_Status.Text + "';";
                    SqlCommand comd2 = new SqlCommand(q2, con);
                    int i = comd2.ExecuteNonQuery();
                    con.Close();

                    if (i > 0)
                    {

                        MessageBox.Show("update successfully", "information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        load();
                        btn_update.Enabled = false;
                        btn_delete.Enabled = false;
                        txt_MaintenanceID.Enabled = true;
                    }
                    else
                    {
                        MessageBox.Show("Error", "alert", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                    con.Close();
                }
            }
        }
    }
}
