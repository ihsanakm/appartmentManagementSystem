﻿namespace E_Appartment.Admin
{
    partial class Lease
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dataGridView_Lease = new System.Windows.Forms.DataGridView();
            this.comboBox_ParkingSpaces = new System.Windows.Forms.ComboBox();
            this.txt_LeaseEndDate = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.btn_save = new System.Windows.Forms.Button();
            this.btn_clear = new System.Windows.Forms.Button();
            this.btn_update = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            this.txt_CustomerID = new System.Windows.Forms.TextBox();
            this.txt_dependent = new System.Windows.Forms.TextBox();
            this.txt_ApartmentID = new System.Windows.Forms.TextBox();
            this.txt_LeaseID = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_LeasePeriod = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_LeaseStartDate = new System.Windows.Forms.DateTimePicker();
            this.txt_Advance = new System.Windows.Forms.TextBox();
            this.txt_Rent = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.comboBox_servent = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Lease)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView_Lease
            // 
            this.dataGridView_Lease.AllowUserToAddRows = false;
            this.dataGridView_Lease.AllowUserToDeleteRows = false;
            this.dataGridView_Lease.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_Lease.BackgroundColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.Magenta;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Perpetua Titling MT", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.Padding = new System.Windows.Forms.Padding(0, 10, 0, 10);
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.Orchid;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_Lease.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView_Lease.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_Lease.Cursor = System.Windows.Forms.Cursors.Cross;
            this.dataGridView_Lease.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dataGridView_Lease.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnF2;
            this.dataGridView_Lease.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dataGridView_Lease.Location = new System.Drawing.Point(0, 366);
            this.dataGridView_Lease.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridView_Lease.Name = "dataGridView_Lease";
            this.dataGridView_Lease.ReadOnly = true;
            this.dataGridView_Lease.RowHeadersVisible = false;
            this.dataGridView_Lease.RowHeadersWidth = 51;
            this.dataGridView_Lease.RowTemplate.Height = 28;
            this.dataGridView_Lease.ShowEditingIcon = false;
            this.dataGridView_Lease.Size = new System.Drawing.Size(850, 243);
            this.dataGridView_Lease.TabIndex = 140;
            this.dataGridView_Lease.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataGridView_Lease_CellContentClick);
            // 
            // comboBox_ParkingSpaces
            // 
            this.comboBox_ParkingSpaces.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_ParkingSpaces.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_ParkingSpaces.FormattingEnabled = true;
            this.comboBox_ParkingSpaces.Items.AddRange(new object[] {
            "One Vehicle",
            "Two Vehicle"});
            this.comboBox_ParkingSpaces.Location = new System.Drawing.Point(477, 229);
            this.comboBox_ParkingSpaces.Margin = new System.Windows.Forms.Padding(2);
            this.comboBox_ParkingSpaces.Name = "comboBox_ParkingSpaces";
            this.comboBox_ParkingSpaces.Size = new System.Drawing.Size(165, 25);
            this.comboBox_ParkingSpaces.TabIndex = 160;
            // 
            // txt_LeaseEndDate
            // 
            this.txt_LeaseEndDate.CalendarTitleBackColor = System.Drawing.SystemColors.ControlText;
            this.txt_LeaseEndDate.CalendarTitleForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.txt_LeaseEndDate.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_LeaseEndDate.Location = new System.Drawing.Point(477, 175);
            this.txt_LeaseEndDate.Name = "txt_LeaseEndDate";
            this.txt_LeaseEndDate.Size = new System.Drawing.Size(165, 23);
            this.txt_LeaseEndDate.TabIndex = 159;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.SteelBlue;
            this.label3.Location = new System.Drawing.Point(325, 70);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(103, 23);
            this.label3.TabIndex = 158;
            this.label3.Text = "Customer ID";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.SteelBlue;
            this.label8.Location = new System.Drawing.Point(326, 227);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(132, 23);
            this.label8.TabIndex = 157;
            this.label8.Text = "Parking Spaces ";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // btn_save
            // 
            this.btn_save.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_save.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_save.ForeColor = System.Drawing.Color.Black;
            this.btn_save.Location = new System.Drawing.Point(668, 24);
            this.btn_save.Margin = new System.Windows.Forms.Padding(2);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(159, 34);
            this.btn_save.TabIndex = 156;
            this.btn_save.Text = "Save";
            this.btn_save.UseVisualStyleBackColor = false;
            this.btn_save.Click += new System.EventHandler(this.Btn_save_Click);
            // 
            // btn_clear
            // 
            this.btn_clear.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_clear.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_clear.ForeColor = System.Drawing.Color.Black;
            this.btn_clear.Location = new System.Drawing.Point(668, 156);
            this.btn_clear.Margin = new System.Windows.Forms.Padding(2);
            this.btn_clear.Name = "btn_clear";
            this.btn_clear.Size = new System.Drawing.Size(159, 34);
            this.btn_clear.TabIndex = 155;
            this.btn_clear.Text = "Clear";
            this.btn_clear.UseVisualStyleBackColor = false;
            this.btn_clear.Click += new System.EventHandler(this.Btn_clear_Click);
            // 
            // btn_update
            // 
            this.btn_update.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_update.Enabled = false;
            this.btn_update.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_update.ForeColor = System.Drawing.Color.Black;
            this.btn_update.Location = new System.Drawing.Point(668, 93);
            this.btn_update.Margin = new System.Windows.Forms.Padding(2);
            this.btn_update.Name = "btn_update";
            this.btn_update.Size = new System.Drawing.Size(159, 34);
            this.btn_update.TabIndex = 154;
            this.btn_update.Text = "Update";
            this.btn_update.UseVisualStyleBackColor = false;
            this.btn_update.Click += new System.EventHandler(this.Btn_update_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_delete.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn_delete.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.btn_delete.Enabled = false;
            this.btn_delete.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btn_delete.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_delete.ForeColor = System.Drawing.Color.Black;
            this.btn_delete.Location = new System.Drawing.Point(668, 229);
            this.btn_delete.Margin = new System.Windows.Forms.Padding(2);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(159, 34);
            this.btn_delete.TabIndex = 153;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = false;
            this.btn_delete.Click += new System.EventHandler(this.Btn_delete_Click);
            // 
            // txt_CustomerID
            // 
            this.txt_CustomerID.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CustomerID.Location = new System.Drawing.Point(477, 74);
            this.txt_CustomerID.Margin = new System.Windows.Forms.Padding(2);
            this.txt_CustomerID.Multiline = true;
            this.txt_CustomerID.Name = "txt_CustomerID";
            this.txt_CustomerID.Size = new System.Drawing.Size(165, 19);
            this.txt_CustomerID.TabIndex = 152;
            // 
            // txt_dependent
            // 
            this.txt_dependent.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_dependent.Location = new System.Drawing.Point(142, 72);
            this.txt_dependent.Margin = new System.Windows.Forms.Padding(2);
            this.txt_dependent.MaxLength = 10;
            this.txt_dependent.Multiline = true;
            this.txt_dependent.Name = "txt_dependent";
            this.txt_dependent.Size = new System.Drawing.Size(165, 19);
            this.txt_dependent.TabIndex = 150;
            // 
            // txt_ApartmentID
            // 
            this.txt_ApartmentID.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ApartmentID.Location = new System.Drawing.Point(477, 26);
            this.txt_ApartmentID.Margin = new System.Windows.Forms.Padding(2);
            this.txt_ApartmentID.Multiline = true;
            this.txt_ApartmentID.Name = "txt_ApartmentID";
            this.txt_ApartmentID.Size = new System.Drawing.Size(165, 19);
            this.txt_ApartmentID.TabIndex = 148;
            // 
            // txt_LeaseID
            // 
            this.txt_LeaseID.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_LeaseID.Location = new System.Drawing.Point(142, 22);
            this.txt_LeaseID.Margin = new System.Windows.Forms.Padding(2);
            this.txt_LeaseID.Multiline = true;
            this.txt_LeaseID.Name = "txt_LeaseID";
            this.txt_LeaseID.Size = new System.Drawing.Size(165, 19);
            this.txt_LeaseID.TabIndex = 147;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.SteelBlue;
            this.label7.Location = new System.Drawing.Point(325, 118);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(133, 23);
            this.label7.TabIndex = 146;
            this.label7.Text = "Lease Start Date";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.SteelBlue;
            this.label6.Location = new System.Drawing.Point(9, 227);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(68, 23);
            this.label6.TabIndex = 145;
            this.label6.Text = "Servent";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.SteelBlue;
            this.label5.Location = new System.Drawing.Point(9, 70);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(93, 23);
            this.label5.TabIndex = 144;
            this.label5.Text = "Dependent";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.SteelBlue;
            this.label4.Location = new System.Drawing.Point(9, 118);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(109, 23);
            this.label4.TabIndex = 143;
            this.label4.Text = "Lease Period";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.SteelBlue;
            this.label2.Location = new System.Drawing.Point(322, 20);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(108, 23);
            this.label2.TabIndex = 142;
            this.label2.Text = "Apartment ID";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.SteelBlue;
            this.label1.Location = new System.Drawing.Point(9, 20);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 23);
            this.label1.TabIndex = 141;
            this.label1.Text = "Lease ID";
            // 
            // txt_LeasePeriod
            // 
            this.txt_LeasePeriod.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_LeasePeriod.Location = new System.Drawing.Point(142, 122);
            this.txt_LeasePeriod.Margin = new System.Windows.Forms.Padding(2);
            this.txt_LeasePeriod.Multiline = true;
            this.txt_LeasePeriod.Name = "txt_LeasePeriod";
            this.txt_LeasePeriod.Size = new System.Drawing.Size(165, 19);
            this.txt_LeasePeriod.TabIndex = 161;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.SteelBlue;
            this.label9.Location = new System.Drawing.Point(325, 173);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(128, 23);
            this.label9.TabIndex = 162;
            this.label9.Text = "Lease End Date";
            // 
            // txt_LeaseStartDate
            // 
            this.txt_LeaseStartDate.CalendarTitleBackColor = System.Drawing.SystemColors.ControlText;
            this.txt_LeaseStartDate.CalendarTitleForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.txt_LeaseStartDate.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_LeaseStartDate.Location = new System.Drawing.Point(477, 120);
            this.txt_LeaseStartDate.Name = "txt_LeaseStartDate";
            this.txt_LeaseStartDate.Size = new System.Drawing.Size(165, 23);
            this.txt_LeaseStartDate.TabIndex = 165;
            // 
            // txt_Advance
            // 
            this.txt_Advance.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Advance.Location = new System.Drawing.Point(142, 276);
            this.txt_Advance.Margin = new System.Windows.Forms.Padding(2);
            this.txt_Advance.Multiline = true;
            this.txt_Advance.Name = "txt_Advance";
            this.txt_Advance.Size = new System.Drawing.Size(165, 19);
            this.txt_Advance.TabIndex = 169;
            // 
            // txt_Rent
            // 
            this.txt_Rent.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Rent.Location = new System.Drawing.Point(142, 175);
            this.txt_Rent.Margin = new System.Windows.Forms.Padding(2);
            this.txt_Rent.Multiline = true;
            this.txt_Rent.Name = "txt_Rent";
            this.txt_Rent.Size = new System.Drawing.Size(165, 19);
            this.txt_Rent.TabIndex = 168;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.SteelBlue;
            this.label10.Location = new System.Drawing.Point(9, 272);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(77, 23);
            this.label10.TabIndex = 167;
            this.label10.Text = "Advance";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.SteelBlue;
            this.label11.Location = new System.Drawing.Point(9, 173);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(45, 23);
            this.label11.TabIndex = 166;
            this.label11.Text = "Rent";
            // 
            // comboBox_servent
            // 
            this.comboBox_servent.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_servent.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_servent.FormattingEnabled = true;
            this.comboBox_servent.Items.AddRange(new object[] {
            "One",
            "Two",
            "Three",
            "Four",
            "Five"});
            this.comboBox_servent.Location = new System.Drawing.Point(142, 227);
            this.comboBox_servent.Margin = new System.Windows.Forms.Padding(2);
            this.comboBox_servent.Name = "comboBox_servent";
            this.comboBox_servent.Size = new System.Drawing.Size(165, 25);
            this.comboBox_servent.TabIndex = 170;
            // 
            // Lease
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(850, 609);
            this.Controls.Add(this.comboBox_servent);
            this.Controls.Add(this.txt_Advance);
            this.Controls.Add(this.txt_Rent);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.txt_LeaseStartDate);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txt_LeasePeriod);
            this.Controls.Add(this.comboBox_ParkingSpaces);
            this.Controls.Add(this.txt_LeaseEndDate);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.btn_save);
            this.Controls.Add(this.btn_clear);
            this.Controls.Add(this.btn_update);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.txt_CustomerID);
            this.Controls.Add(this.txt_dependent);
            this.Controls.Add(this.txt_ApartmentID);
            this.Controls.Add(this.txt_LeaseID);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView_Lease);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Lease";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Lease";
            this.Load += new System.EventHandler(this.Lease_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Lease)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView dataGridView_Lease;
        private System.Windows.Forms.ComboBox comboBox_ParkingSpaces;
        private System.Windows.Forms.DateTimePicker txt_LeaseEndDate;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btn_save;
        private System.Windows.Forms.Button btn_clear;
        private System.Windows.Forms.Button btn_update;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.TextBox txt_CustomerID;
        private System.Windows.Forms.TextBox txt_dependent;
        private System.Windows.Forms.TextBox txt_ApartmentID;
        private System.Windows.Forms.TextBox txt_LeaseID;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_LeasePeriod;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DateTimePicker txt_LeaseStartDate;
        private System.Windows.Forms.TextBox txt_Advance;
        private System.Windows.Forms.TextBox txt_Rent;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox comboBox_servent;
    }
}