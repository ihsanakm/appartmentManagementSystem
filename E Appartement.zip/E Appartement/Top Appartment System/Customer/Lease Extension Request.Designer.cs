﻿namespace E_Appartment.Customer
{
    partial class Lease_Extension_Request
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.label3 = new System.Windows.Forms.Label();
            this.btn_save = new System.Windows.Forms.Button();
            this.btn_clear = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            this.txt_CurrentLeasePeriod = new System.Windows.Forms.TextBox();
            this.txt_RequestedLeasePeriod = new System.Windows.Forms.TextBox();
            this.txt_Reasonforextension = new System.Windows.Forms.TextBox();
            this.txt_LeaseID = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView_Customer_Lease_Extension_Request = new System.Windows.Forms.DataGridView();
            this.txt_ApartmentID = new System.Windows.Forms.TextBox();
            this.txt_Rent = new System.Windows.Forms.TextBox();
            this.txt_Advance = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Customer_Lease_Extension_Request)).BeginInit();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.SteelBlue;
            this.label3.Location = new System.Drawing.Point(1, 50);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(108, 23);
            this.label3.TabIndex = 167;
            this.label3.Text = "Apartment ID";
            // 
            // btn_save
            // 
            this.btn_save.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_save.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btn_save.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_save.ForeColor = System.Drawing.Color.DarkRed;
            this.btn_save.Location = new System.Drawing.Point(112, 215);
            this.btn_save.Margin = new System.Windows.Forms.Padding(2);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(145, 26);
            this.btn_save.TabIndex = 166;
            this.btn_save.Text = "Save";
            this.btn_save.UseVisualStyleBackColor = false;
            this.btn_save.Click += new System.EventHandler(this.Btn_save_Click);
            // 
            // btn_clear
            // 
            this.btn_clear.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_clear.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btn_clear.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_clear.ForeColor = System.Drawing.Color.DarkRed;
            this.btn_clear.Location = new System.Drawing.Point(337, 215);
            this.btn_clear.Margin = new System.Windows.Forms.Padding(2);
            this.btn_clear.Name = "btn_clear";
            this.btn_clear.Size = new System.Drawing.Size(145, 26);
            this.btn_clear.TabIndex = 165;
            this.btn_clear.Text = "Clear";
            this.btn_clear.UseVisualStyleBackColor = false;
            this.btn_clear.Click += new System.EventHandler(this.Btn_clear_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_delete.Cursor = System.Windows.Forms.Cursors.AppStarting;
            this.btn_delete.Enabled = false;
            this.btn_delete.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btn_delete.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_delete.ForeColor = System.Drawing.Color.DarkRed;
            this.btn_delete.Location = new System.Drawing.Point(549, 216);
            this.btn_delete.Margin = new System.Windows.Forms.Padding(2);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(145, 25);
            this.btn_delete.TabIndex = 163;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = false;
            this.btn_delete.Click += new System.EventHandler(this.Btn_delete_Click);
            // 
            // txt_CurrentLeasePeriod
            // 
            this.txt_CurrentLeasePeriod.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CurrentLeasePeriod.Location = new System.Drawing.Point(595, 10);
            this.txt_CurrentLeasePeriod.Margin = new System.Windows.Forms.Padding(2);
            this.txt_CurrentLeasePeriod.Multiline = true;
            this.txt_CurrentLeasePeriod.Name = "txt_CurrentLeasePeriod";
            this.txt_CurrentLeasePeriod.Size = new System.Drawing.Size(165, 19);
            this.txt_CurrentLeasePeriod.TabIndex = 162;
            // 
            // txt_RequestedLeasePeriod
            // 
            this.txt_RequestedLeasePeriod.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_RequestedLeasePeriod.Location = new System.Drawing.Point(595, 55);
            this.txt_RequestedLeasePeriod.Margin = new System.Windows.Forms.Padding(2);
            this.txt_RequestedLeasePeriod.MaxLength = 10;
            this.txt_RequestedLeasePeriod.Multiline = true;
            this.txt_RequestedLeasePeriod.Name = "txt_RequestedLeasePeriod";
            this.txt_RequestedLeasePeriod.Size = new System.Drawing.Size(165, 19);
            this.txt_RequestedLeasePeriod.TabIndex = 161;
            // 
            // txt_Reasonforextension
            // 
            this.txt_Reasonforextension.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Reasonforextension.Location = new System.Drawing.Point(178, 104);
            this.txt_Reasonforextension.Margin = new System.Windows.Forms.Padding(2);
            this.txt_Reasonforextension.Multiline = true;
            this.txt_Reasonforextension.Name = "txt_Reasonforextension";
            this.txt_Reasonforextension.Size = new System.Drawing.Size(165, 19);
            this.txt_Reasonforextension.TabIndex = 160;
            // 
            // txt_LeaseID
            // 
            this.txt_LeaseID.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_LeaseID.Location = new System.Drawing.Point(178, 6);
            this.txt_LeaseID.Margin = new System.Windows.Forms.Padding(2);
            this.txt_LeaseID.Multiline = true;
            this.txt_LeaseID.Name = "txt_LeaseID";
            this.txt_LeaseID.Size = new System.Drawing.Size(165, 19);
            this.txt_LeaseID.TabIndex = 159;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.SteelBlue;
            this.label6.Location = new System.Drawing.Point(373, 6);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(170, 23);
            this.label6.TabIndex = 157;
            this.label6.Text = "Current Lease Period";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.SteelBlue;
            this.label5.Location = new System.Drawing.Point(373, 50);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(195, 23);
            this.label5.TabIndex = 156;
            this.label5.Text = "Requested Lease Period";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.SteelBlue;
            this.label4.Location = new System.Drawing.Point(1, 100);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(173, 23);
            this.label4.TabIndex = 155;
            this.label4.Text = "Reason for Extension";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.SteelBlue;
            this.label1.Location = new System.Drawing.Point(1, 4);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 23);
            this.label1.TabIndex = 154;
            this.label1.Text = "Lease ID";
            // 
            // dataGridView_Customer_Lease_Extension_Request
            // 
            this.dataGridView_Customer_Lease_Extension_Request.AllowUserToAddRows = false;
            this.dataGridView_Customer_Lease_Extension_Request.AllowUserToDeleteRows = false;
            this.dataGridView_Customer_Lease_Extension_Request.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_Customer_Lease_Extension_Request.BackgroundColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Magenta;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Perpetua Titling MT", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.Padding = new System.Windows.Forms.Padding(0, 10, 0, 10);
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Orchid;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_Customer_Lease_Extension_Request.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView_Customer_Lease_Extension_Request.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_Customer_Lease_Extension_Request.Cursor = System.Windows.Forms.Cursors.Cross;
            this.dataGridView_Customer_Lease_Extension_Request.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dataGridView_Customer_Lease_Extension_Request.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnF2;
            this.dataGridView_Customer_Lease_Extension_Request.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dataGridView_Customer_Lease_Extension_Request.Location = new System.Drawing.Point(0, 308);
            this.dataGridView_Customer_Lease_Extension_Request.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridView_Customer_Lease_Extension_Request.Name = "dataGridView_Customer_Lease_Extension_Request";
            this.dataGridView_Customer_Lease_Extension_Request.ReadOnly = true;
            this.dataGridView_Customer_Lease_Extension_Request.RowHeadersVisible = false;
            this.dataGridView_Customer_Lease_Extension_Request.RowHeadersWidth = 51;
            this.dataGridView_Customer_Lease_Extension_Request.RowTemplate.Height = 28;
            this.dataGridView_Customer_Lease_Extension_Request.ShowEditingIcon = false;
            this.dataGridView_Customer_Lease_Extension_Request.Size = new System.Drawing.Size(792, 301);
            this.dataGridView_Customer_Lease_Extension_Request.TabIndex = 153;
            this.dataGridView_Customer_Lease_Extension_Request.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataGridView_Customer_Lease_Extension_Request_CellContentClick);
            // 
            // txt_ApartmentID
            // 
            this.txt_ApartmentID.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ApartmentID.Location = new System.Drawing.Point(178, 52);
            this.txt_ApartmentID.Margin = new System.Windows.Forms.Padding(2);
            this.txt_ApartmentID.Multiline = true;
            this.txt_ApartmentID.Name = "txt_ApartmentID";
            this.txt_ApartmentID.Size = new System.Drawing.Size(165, 19);
            this.txt_ApartmentID.TabIndex = 169;
            // 
            // txt_Rent
            // 
            this.txt_Rent.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Rent.Location = new System.Drawing.Point(595, 100);
            this.txt_Rent.Margin = new System.Windows.Forms.Padding(2);
            this.txt_Rent.MaxLength = 10;
            this.txt_Rent.Multiline = true;
            this.txt_Rent.Name = "txt_Rent";
            this.txt_Rent.Size = new System.Drawing.Size(165, 19);
            this.txt_Rent.TabIndex = 173;
            // 
            // txt_Advance
            // 
            this.txt_Advance.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Advance.Location = new System.Drawing.Point(178, 158);
            this.txt_Advance.Margin = new System.Windows.Forms.Padding(2);
            this.txt_Advance.Multiline = true;
            this.txt_Advance.Name = "txt_Advance";
            this.txt_Advance.Size = new System.Drawing.Size(165, 19);
            this.txt_Advance.TabIndex = 172;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.SteelBlue;
            this.label2.Location = new System.Drawing.Point(379, 98);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 23);
            this.label2.TabIndex = 171;
            this.label2.Text = "Rent";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.SteelBlue;
            this.label8.Location = new System.Drawing.Point(1, 154);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(77, 23);
            this.label8.TabIndex = 170;
            this.label8.Text = "Advance";
            // 
            // Lease_Extension_Request
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(792, 609);
            this.Controls.Add(this.txt_Rent);
            this.Controls.Add(this.txt_Advance);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txt_ApartmentID);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btn_save);
            this.Controls.Add(this.btn_clear);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.txt_CurrentLeasePeriod);
            this.Controls.Add(this.txt_RequestedLeasePeriod);
            this.Controls.Add(this.txt_Reasonforextension);
            this.Controls.Add(this.txt_LeaseID);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView_Customer_Lease_Extension_Request);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Lease_Extension_Request";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Lease_Extension_Request";
            this.Load += new System.EventHandler(this.Lease_Extension_Request_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Customer_Lease_Extension_Request)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btn_save;
        private System.Windows.Forms.Button btn_clear;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.TextBox txt_CurrentLeasePeriod;
        private System.Windows.Forms.TextBox txt_RequestedLeasePeriod;
        private System.Windows.Forms.TextBox txt_Reasonforextension;
        private System.Windows.Forms.TextBox txt_LeaseID;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView_Customer_Lease_Extension_Request;
        private System.Windows.Forms.TextBox txt_ApartmentID;
        private System.Windows.Forms.TextBox txt_Rent;
        private System.Windows.Forms.TextBox txt_Advance;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label8;
    }
}