﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace E_Appartment.Customer
{
    public partial class Lease_Extension_Request : Form
    {

        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-PBEM3OT\SQLEXPRESS;Initial Catalog=Top_Appartment;Integrated Security=True");

        public Lease_Extension_Request()
        {
            InitializeComponent();
        }

        private void Lease_Extension_Request_Load(object sender, EventArgs e)
        {
            load();
        }

        void load()
        {
            try
            {
                con.Open();
                string sql = "select * from Customer_Lease_Extension_Request;";
                SqlDataAdapter adapter = new SqlDataAdapter(sql, con);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dataGridView_Customer_Lease_Extension_Request.DataSource = dt;
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void Btn_save_Click(object sender, EventArgs e)
        {
            if (txt_LeaseID.Text == "" )
            {
                MessageBox.Show("fill all field");
            }
            else
            {
                try
                {
                    con.Open();
                    string q1 = "insert into Customer_Lease_Extension_Request values ('" + txt_LeaseID.Text + "','" + txt_CurrentLeasePeriod.Text + "','" + txt_Rent.Text + "','" + txt_ApartmentID.Text + "','" + txt_RequestedLeasePeriod.Text + "','" + txt_Advance.Text + "','" + txt_Reasonforextension.Text + "','None');";
                    MessageBox.Show(q1);
                    SqlCommand comd1 = new SqlCommand(q1, con);
                    int i = comd1.ExecuteNonQuery();
                    con.Close();

                    if (i > 0)
                    {
                        load();
                        MessageBox.Show("Insert successfully", "information", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    }
                    else
                    {
                        MessageBox.Show("Error", "alert", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                    con.Close();
                }


            }
        }

        private void Btn_clear_Click(object sender, EventArgs e)
        {
            txt_LeaseID.Text = "";
            txt_CurrentLeasePeriod.Clear();
            txt_Rent.Clear();
            txt_ApartmentID.Clear();
            txt_RequestedLeasePeriod.Clear();
            txt_Advance.Clear();
            txt_Reasonforextension.Clear();

            btn_delete.Enabled = false;
            txt_LeaseID.Enabled = true;
        }

        private void Btn_delete_Click(object sender, EventArgs e)
        {
            if (txt_LeaseID.Text == "")
            {
                MessageBox.Show("fill all field");
            }
            else
            {
                try
                {
                    con.Open();
                    string q1 = "delete Customer_Lease_Extension_Request where LeaseID = '" + txt_LeaseID.Text + "'";
                    SqlCommand comd1 = new SqlCommand(q1, con);
                    int i = comd1.ExecuteNonQuery();
                    con.Close();

                    if (i > 0)
                    {
                        MessageBox.Show("delete successfully", "information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        load();
                        btn_delete.Enabled = false;
                        txt_LeaseID.Enabled = true;
                    }
                    else
                    {
                        MessageBox.Show("Error", "alert", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }


            }
        }

        private void DataGridView_Customer_Lease_Extension_Request_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {

                txt_LeaseID.Text = dataGridView_Customer_Lease_Extension_Request.Rows[e.RowIndex].Cells[0].Value.ToString();
                txt_CurrentLeasePeriod.Text = dataGridView_Customer_Lease_Extension_Request.Rows[e.RowIndex].Cells[1].Value.ToString();
                txt_Rent.Text = dataGridView_Customer_Lease_Extension_Request.Rows[e.RowIndex].Cells[2].Value.ToString();
                txt_ApartmentID.Text = dataGridView_Customer_Lease_Extension_Request.Rows[e.RowIndex].Cells[3].Value.ToString();
                txt_RequestedLeasePeriod.Text = dataGridView_Customer_Lease_Extension_Request.Rows[e.RowIndex].Cells[4].Value.ToString();
                txt_Advance.Text = dataGridView_Customer_Lease_Extension_Request.Rows[e.RowIndex].Cells[5].Value.ToString();
                txt_Reasonforextension.Text = dataGridView_Customer_Lease_Extension_Request.Rows[e.RowIndex].Cells[6].Value.ToString();

                btn_delete.Enabled = true;

                txt_LeaseID.Enabled = false;
            }
        }
    }
}
