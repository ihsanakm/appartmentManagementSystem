﻿namespace E_Appartment.Customer
{
    partial class Customer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.pnlnav = new System.Windows.Forms.Panel();
            this.BTN_LOGOUT = new System.Windows.Forms.Button();
            this.BTN_Lease_Extension_Request = new System.Windows.Forms.Button();
            this.BTN_Apartment = new System.Windows.Forms.Button();
            this.BTN_Dashboard = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lblHead = new System.Windows.Forms.Label();
            this.pnl_Main_Customer = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.panel1.Controls.Add(this.pnlnav);
            this.panel1.Controls.Add(this.BTN_LOGOUT);
            this.panel1.Controls.Add(this.BTN_Lease_Extension_Request);
            this.panel1.Controls.Add(this.BTN_Apartment);
            this.panel1.Controls.Add(this.BTN_Dashboard);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(188, 640);
            this.panel1.TabIndex = 2;
            // 
            // pnlnav
            // 
            this.pnlnav.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.pnlnav.Location = new System.Drawing.Point(0, 157);
            this.pnlnav.Margin = new System.Windows.Forms.Padding(2);
            this.pnlnav.Name = "pnlnav";
            this.pnlnav.Size = new System.Drawing.Size(2, 81);
            this.pnlnav.TabIndex = 2;
            // 
            // BTN_LOGOUT
            // 
            this.BTN_LOGOUT.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.BTN_LOGOUT.FlatAppearance.BorderSize = 0;
            this.BTN_LOGOUT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTN_LOGOUT.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_LOGOUT.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.BTN_LOGOUT.Location = new System.Drawing.Point(0, 581);
            this.BTN_LOGOUT.Margin = new System.Windows.Forms.Padding(2);
            this.BTN_LOGOUT.Name = "BTN_LOGOUT";
            this.BTN_LOGOUT.Size = new System.Drawing.Size(188, 59);
            this.BTN_LOGOUT.TabIndex = 1;
            this.BTN_LOGOUT.Text = "LOGOUT";
            this.BTN_LOGOUT.UseVisualStyleBackColor = true;
            this.BTN_LOGOUT.Click += new System.EventHandler(this.BTN_LOGOUT_Click);
            // 
            // BTN_Lease_Extension_Request
            // 
            this.BTN_Lease_Extension_Request.Dock = System.Windows.Forms.DockStyle.Top;
            this.BTN_Lease_Extension_Request.FlatAppearance.BorderSize = 0;
            this.BTN_Lease_Extension_Request.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTN_Lease_Extension_Request.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_Lease_Extension_Request.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.BTN_Lease_Extension_Request.Location = new System.Drawing.Point(0, 245);
            this.BTN_Lease_Extension_Request.Margin = new System.Windows.Forms.Padding(2);
            this.BTN_Lease_Extension_Request.Name = "BTN_Lease_Extension_Request";
            this.BTN_Lease_Extension_Request.Size = new System.Drawing.Size(188, 57);
            this.BTN_Lease_Extension_Request.TabIndex = 1;
            this.BTN_Lease_Extension_Request.Text = "Lease Extension Request";
            this.BTN_Lease_Extension_Request.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BTN_Lease_Extension_Request.UseVisualStyleBackColor = true;
            this.BTN_Lease_Extension_Request.Click += new System.EventHandler(this.BTN_Lease_Extension_Request_Click);
            // 
            // BTN_Apartment
            // 
            this.BTN_Apartment.Dock = System.Windows.Forms.DockStyle.Top;
            this.BTN_Apartment.FlatAppearance.BorderSize = 0;
            this.BTN_Apartment.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTN_Apartment.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_Apartment.ForeColor = System.Drawing.Color.SteelBlue;
            this.BTN_Apartment.Location = new System.Drawing.Point(0, 188);
            this.BTN_Apartment.Margin = new System.Windows.Forms.Padding(2);
            this.BTN_Apartment.Name = "BTN_Apartment";
            this.BTN_Apartment.Size = new System.Drawing.Size(188, 57);
            this.BTN_Apartment.TabIndex = 1;
            this.BTN_Apartment.Text = "Apartment ";
            this.BTN_Apartment.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BTN_Apartment.UseVisualStyleBackColor = true;
            this.BTN_Apartment.Click += new System.EventHandler(this.BTN_Apartment_Click);
            // 
            // BTN_Dashboard
            // 
            this.BTN_Dashboard.Dock = System.Windows.Forms.DockStyle.Top;
            this.BTN_Dashboard.FlatAppearance.BorderSize = 0;
            this.BTN_Dashboard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTN_Dashboard.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_Dashboard.ForeColor = System.Drawing.Color.SteelBlue;
            this.BTN_Dashboard.Location = new System.Drawing.Point(0, 131);
            this.BTN_Dashboard.Margin = new System.Windows.Forms.Padding(2);
            this.BTN_Dashboard.Name = "BTN_Dashboard";
            this.BTN_Dashboard.Size = new System.Drawing.Size(188, 57);
            this.BTN_Dashboard.TabIndex = 1;
            this.BTN_Dashboard.Text = "Dashboard";
            this.BTN_Dashboard.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BTN_Dashboard.UseVisualStyleBackColor = true;
            this.BTN_Dashboard.Click += new System.EventHandler(this.BTN_Dashboard_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(188, 131);
            this.panel2.TabIndex = 1;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(188, 128);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.SteelBlue;
            this.panel3.Controls.Add(this.lblHead);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(188, 0);
            this.panel3.Margin = new System.Windows.Forms.Padding(2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(852, 81);
            this.panel3.TabIndex = 3;
            // 
            // lblHead
            // 
            this.lblHead.AutoSize = true;
            this.lblHead.Font = new System.Drawing.Font("Arial Narrow", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHead.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblHead.Location = new System.Drawing.Point(414, 28);
            this.lblHead.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblHead.Name = "lblHead";
            this.lblHead.Size = new System.Drawing.Size(131, 31);
            this.lblHead.TabIndex = 0;
            this.lblHead.Text = "Dashboard";
            // 
            // pnl_Main_Customer
            // 
            this.pnl_Main_Customer.BackColor = System.Drawing.Color.LightSteelBlue;
            this.pnl_Main_Customer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnl_Main_Customer.Location = new System.Drawing.Point(188, 81);
            this.pnl_Main_Customer.Margin = new System.Windows.Forms.Padding(2);
            this.pnl_Main_Customer.Name = "pnl_Main_Customer";
            this.pnl_Main_Customer.Size = new System.Drawing.Size(852, 559);
            this.pnl_Main_Customer.TabIndex = 4;
            this.pnl_Main_Customer.Paint += new System.Windows.Forms.PaintEventHandler(this.pnl_Main_Customer_Paint);
            // 
            // Customer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.ClientSize = new System.Drawing.Size(1040, 640);
            this.Controls.Add(this.pnl_Main_Customer);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Customer";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Customer";
            this.Load += new System.EventHandler(this.Customer_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel pnlnav;
        private System.Windows.Forms.Button BTN_LOGOUT;
        private System.Windows.Forms.Button BTN_Lease_Extension_Request;
        private System.Windows.Forms.Button BTN_Apartment;
        private System.Windows.Forms.Button BTN_Dashboard;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lblHead;
        private System.Windows.Forms.Panel pnl_Main_Customer;
    }
}