﻿namespace E_Appartment
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login));
            this.btn_EXIT = new System.Windows.Forms.Button();
            this.btn_Login = new System.Windows.Forms.Button();
            this.txt_Password = new System.Windows.Forms.TextBox();
            this.Password = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_Mail = new System.Windows.Forms.TextBox();
            this.UserID = new System.Windows.Forms.Label();
            this.Type = new System.Windows.Forms.Label();
            this.comboBox_Type = new System.Windows.Forms.ComboBox();
            this.lbl_MailError = new System.Windows.Forms.Label();
            this.lbl_PassError = new System.Windows.Forms.Label();
            this.lbl_TypeError = new System.Windows.Forms.Label();
            this.lbl_Error = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_EXIT
            // 
            this.btn_EXIT.BackColor = System.Drawing.Color.White;
            this.btn_EXIT.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btn_EXIT.Font = new System.Drawing.Font("Arial Narrow", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_EXIT.Location = new System.Drawing.Point(106, 584);
            this.btn_EXIT.Margin = new System.Windows.Forms.Padding(2);
            this.btn_EXIT.Name = "btn_EXIT";
            this.btn_EXIT.Size = new System.Drawing.Size(367, 33);
            this.btn_EXIT.TabIndex = 15;
            this.btn_EXIT.Text = "Close";
            this.btn_EXIT.UseVisualStyleBackColor = false;
            this.btn_EXIT.Click += new System.EventHandler(this.Btn_EXIT_Click);
            // 
            // btn_Login
            // 
            this.btn_Login.BackColor = System.Drawing.Color.White;
            this.btn_Login.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btn_Login.Font = new System.Drawing.Font("Arial Narrow", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Login.Location = new System.Drawing.Point(106, 512);
            this.btn_Login.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Login.Name = "btn_Login";
            this.btn_Login.Size = new System.Drawing.Size(367, 35);
            this.btn_Login.TabIndex = 14;
            this.btn_Login.Text = "Login";
            this.btn_Login.UseVisualStyleBackColor = false;
            this.btn_Login.Click += new System.EventHandler(this.Btn_Login_Click);
            // 
            // txt_Password
            // 
            this.txt_Password.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txt_Password.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_Password.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Password.Location = new System.Drawing.Point(251, 438);
            this.txt_Password.Margin = new System.Windows.Forms.Padding(2);
            this.txt_Password.Name = "txt_Password";
            this.txt_Password.Size = new System.Drawing.Size(261, 23);
            this.txt_Password.TabIndex = 13;
            this.txt_Password.UseSystemPasswordChar = true;
            // 
            // Password
            // 
            this.Password.AutoSize = true;
            this.Password.BackColor = System.Drawing.Color.Transparent;
            this.Password.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Password.ForeColor = System.Drawing.Color.SteelBlue;
            this.Password.Location = new System.Drawing.Point(65, 431);
            this.Password.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Password.Name = "Password";
            this.Password.Size = new System.Drawing.Size(143, 32);
            this.Password.TabIndex = 12;
            this.Password.Text = "Password";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Nirmala UI", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.LightYellow;
            this.label2.Location = new System.Drawing.Point(44, 364);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 47);
            this.label2.TabIndex = 11;
            // 
            // txt_Mail
            // 
            this.txt_Mail.BackColor = System.Drawing.Color.White;
            this.txt_Mail.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_Mail.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Mail.Location = new System.Drawing.Point(249, 308);
            this.txt_Mail.Margin = new System.Windows.Forms.Padding(2);
            this.txt_Mail.Multiline = true;
            this.txt_Mail.Name = "txt_Mail";
            this.txt_Mail.Size = new System.Drawing.Size(261, 25);
            this.txt_Mail.TabIndex = 10;
            // 
            // UserID
            // 
            this.UserID.AutoSize = true;
            this.UserID.BackColor = System.Drawing.Color.Transparent;
            this.UserID.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UserID.ForeColor = System.Drawing.Color.SteelBlue;
            this.UserID.Location = new System.Drawing.Point(65, 304);
            this.UserID.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.UserID.Name = "UserID";
            this.UserID.Size = new System.Drawing.Size(89, 32);
            this.UserID.TabIndex = 9;
            this.UserID.Text = "Email";
            // 
            // Type
            // 
            this.Type.AutoSize = true;
            this.Type.BackColor = System.Drawing.Color.Transparent;
            this.Type.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Type.ForeColor = System.Drawing.Color.SteelBlue;
            this.Type.Location = new System.Drawing.Point(65, 368);
            this.Type.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Type.Name = "Type";
            this.Type.Size = new System.Drawing.Size(77, 32);
            this.Type.TabIndex = 16;
            this.Type.Text = "Type";
            this.Type.Click += new System.EventHandler(this.Type_Click);
            // 
            // comboBox_Type
            // 
            this.comboBox_Type.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Type.FormattingEnabled = true;
            this.comboBox_Type.Items.AddRange(new object[] {
            "Admin",
            "Clerk",
            "Customer"});
            this.comboBox_Type.Location = new System.Drawing.Point(251, 375);
            this.comboBox_Type.Margin = new System.Windows.Forms.Padding(2);
            this.comboBox_Type.Name = "comboBox_Type";
            this.comboBox_Type.Size = new System.Drawing.Size(261, 21);
            this.comboBox_Type.TabIndex = 17;
            // 
            // lbl_MailError
            // 
            this.lbl_MailError.AutoSize = true;
            this.lbl_MailError.BackColor = System.Drawing.Color.Transparent;
            this.lbl_MailError.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_MailError.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_MailError.Location = new System.Drawing.Point(248, 334);
            this.lbl_MailError.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_MailError.Name = "lbl_MailError";
            this.lbl_MailError.Size = new System.Drawing.Size(80, 17);
            this.lbl_MailError.TabIndex = 18;
            this.lbl_MailError.Text = "Enter Email";
            this.lbl_MailError.Click += new System.EventHandler(this.lbl_MailError_Click);
            // 
            // lbl_PassError
            // 
            this.lbl_PassError.AutoSize = true;
            this.lbl_PassError.BackColor = System.Drawing.Color.Transparent;
            this.lbl_PassError.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PassError.ForeColor = System.Drawing.Color.Maroon;
            this.lbl_PassError.Location = new System.Drawing.Point(249, 462);
            this.lbl_PassError.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_PassError.Name = "lbl_PassError";
            this.lbl_PassError.Size = new System.Drawing.Size(107, 17);
            this.lbl_PassError.TabIndex = 19;
            this.lbl_PassError.Text = "Enter Password";
            // 
            // lbl_TypeError
            // 
            this.lbl_TypeError.AutoSize = true;
            this.lbl_TypeError.BackColor = System.Drawing.Color.Transparent;
            this.lbl_TypeError.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TypeError.ForeColor = System.Drawing.Color.Maroon;
            this.lbl_TypeError.Location = new System.Drawing.Point(248, 397);
            this.lbl_TypeError.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_TypeError.Name = "lbl_TypeError";
            this.lbl_TypeError.Size = new System.Drawing.Size(83, 17);
            this.lbl_TypeError.TabIndex = 20;
            this.lbl_TypeError.Text = "Select Type";
            this.lbl_TypeError.Click += new System.EventHandler(this.lbl_TypeError_Click);
            // 
            // lbl_Error
            // 
            this.lbl_Error.AutoSize = true;
            this.lbl_Error.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Error.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Error.ForeColor = System.Drawing.Color.Red;
            this.lbl_Error.Location = new System.Drawing.Point(154, 619);
            this.lbl_Error.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_Error.Name = "lbl_Error";
            this.lbl_Error.Size = new System.Drawing.Size(0, 17);
            this.lbl_Error.TabIndex = 21;
            this.lbl_Error.Click += new System.EventHandler(this.lbl_Error_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(580, 281);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox1.TabIndex = 22;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(580, 640);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lbl_Error);
            this.Controls.Add(this.lbl_TypeError);
            this.Controls.Add(this.lbl_PassError);
            this.Controls.Add(this.lbl_MailError);
            this.Controls.Add(this.comboBox_Type);
            this.Controls.Add(this.Type);
            this.Controls.Add(this.btn_EXIT);
            this.Controls.Add(this.btn_Login);
            this.Controls.Add(this.txt_Password);
            this.Controls.Add(this.Password);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txt_Mail);
            this.Controls.Add(this.UserID);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Location = new System.Drawing.Point(20, 10);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Login";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Login";
            this.Load += new System.EventHandler(this.Login_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_EXIT;
        private System.Windows.Forms.Button btn_Login;
        private System.Windows.Forms.TextBox txt_Password;
        private System.Windows.Forms.Label Password;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_Mail;
        private System.Windows.Forms.Label UserID;
        private System.Windows.Forms.Label Type;
        private System.Windows.Forms.ComboBox comboBox_Type;
        private System.Windows.Forms.Label lbl_MailError;
        private System.Windows.Forms.Label lbl_PassError;
        private System.Windows.Forms.Label lbl_TypeError;
        private System.Windows.Forms.Label lbl_Error;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

