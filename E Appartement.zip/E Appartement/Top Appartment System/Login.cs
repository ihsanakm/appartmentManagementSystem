﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace E_Appartment
{
    public partial class Login : Form
    {

        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-PBEM3OT\SQLEXPRESS;Initial Catalog=Top_Appartment;Integrated Security=True");
        public Login()
        {
            InitializeComponent();
            this.SetStyle(ControlStyles.ResizeRedraw, true);
        }
        private const int cGrip = 16;
        private const int cCaption = 32;

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == 0x84)
            {
                Point pos = new Point(m.LParam.ToInt32());
                pos = this.PointToClient(pos);
                if (pos.Y < cCaption)
                {

                    m.Result = (IntPtr)2;
                    return;
                }
                if (pos.X >= this.ClientSize.Width - cGrip && pos.Y >= this.ClientSize.Height - cGrip)
                {
                    m.Result = (IntPtr)17;
                    return;
                }
            }
            base.WndProc(ref m);


        }

        private void Login_Load(object sender, EventArgs e)
        {
            lbl_Error.Text = "";
            lbl_MailError.Text = "";
            lbl_PassError.Text = "";
            lbl_TypeError.Text = "";
        }

        private void Btn_EXIT_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Btn_Login_Click(object sender, EventArgs e)//Login Function
        {
            String Mail = txt_Mail.Text;
            String Password = txt_Password.Text;
            String UserType = comboBox_Type.Text;//Combo Box

            //Database Connection
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-PBEM3OT\SQLEXPRESS;Initial Catalog=Top_Appartment;Integrated Security=True"); // making connection
            SqlDataAdapter sda = new SqlDataAdapter("SELECT * FROM user_Manage WHERE mail = '" + Mail + "' AND password = '" + Password + "'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (Mail == "")
            {
                lbl_MailError.Text = "Enter your Email !";
            }

            else if (Password == "")
            {
                lbl_PassError.Text = "Enter your Password !";
            }

            else if (UserType == "")
            {
                lbl_TypeError.Text = "Select the User Type !";
            }

            else if (dt.Rows.Count == 1)
            {
                if (UserType == "Admin")
                {
                    AdminDashboard AD = new AdminDashboard();
                    this.Hide();
                    AD.Show();
                }

                else if (UserType == "Clerk")
                {
                    Clerk.Clerk CD = new Clerk.Clerk();
                    this.Hide();
                    CD.Show();
                }

                else if (UserType == "Customer")
                {
                    Customer.Customer CustomerDash = new Customer.Customer();
                    this.Hide();
                    CustomerDash.Show();
                }
            }

            else
            {
           
                MessageBox.Show("Invalid Email or Password");
            }

        }

        private void lbl_MailError_Click(object sender, EventArgs e)
        {

        }

        private void lbl_TypeError_Click(object sender, EventArgs e)
        {

        }

        private void lbl_Error_Click(object sender, EventArgs e)
        {

        }

        private void Type_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
