﻿namespace E_Appartment.Clerk
{
    partial class Apartment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dataGridView_Clerk_Apartment = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Clerk_Apartment)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView_Clerk_Apartment
            // 
            this.dataGridView_Clerk_Apartment.AllowUserToAddRows = false;
            this.dataGridView_Clerk_Apartment.AllowUserToDeleteRows = false;
            this.dataGridView_Clerk_Apartment.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_Clerk_Apartment.BackgroundColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Magenta;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Perpetua Titling MT", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.Padding = new System.Windows.Forms.Padding(0, 10, 0, 10);
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Orchid;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_Clerk_Apartment.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView_Clerk_Apartment.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_Clerk_Apartment.Cursor = System.Windows.Forms.Cursors.Cross;
            this.dataGridView_Clerk_Apartment.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnF2;
            this.dataGridView_Clerk_Apartment.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dataGridView_Clerk_Apartment.Location = new System.Drawing.Point(0, 0);
            this.dataGridView_Clerk_Apartment.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridView_Clerk_Apartment.Name = "dataGridView_Clerk_Apartment";
            this.dataGridView_Clerk_Apartment.ReadOnly = true;
            this.dataGridView_Clerk_Apartment.RowHeadersVisible = false;
            this.dataGridView_Clerk_Apartment.RowHeadersWidth = 51;
            this.dataGridView_Clerk_Apartment.RowTemplate.Height = 28;
            this.dataGridView_Clerk_Apartment.ShowEditingIcon = false;
            this.dataGridView_Clerk_Apartment.Size = new System.Drawing.Size(850, 609);
            this.dataGridView_Clerk_Apartment.TabIndex = 100;
            this.dataGridView_Clerk_Apartment.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataGridView_Clerk_Apartment_CellContentClick);
            // 
            // Apartment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.ClientSize = new System.Drawing.Size(975, 609);
            this.Controls.Add(this.dataGridView_Clerk_Apartment);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Apartment";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Apartment";
            this.Load += new System.EventHandler(this.Apartment_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Clerk_Apartment)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView_Clerk_Apartment;
    }
}