﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace E_Appartment.Clerk
{
    public partial class Clerk : Form
    {

        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]

        private static extern IntPtr CreateRoundRectRgn

    (

    int nLeftRect,
    int nTopRect,
    int nRightRect,
    int nBottomRect,
    int nWidthEllipse,
    int nHeightEllipse

    );

        public Clerk()
        {
            InitializeComponent();
            Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, Width, Height, 25, 25));
            pnlnav.Height = BTN_Dashboard.Height;
            pnlnav.Top = BTN_Dashboard.Top;
            pnlnav.Left = BTN_Dashboard.Left;
            BTN_Dashboard.BackColor = Color.FromArgb(46, 51, 73);
        }

        public void LoadForms(object Forms)
        {
            if (this.pnl_Main_Clerk.Controls.Count > 0)
                this.pnl_Main_Clerk.Controls.RemoveAt(0);
            Form f = Forms as Form;
            f.TopLevel = false;
            f.Dock = DockStyle.Fill;
            this.pnl_Main_Clerk.Controls.Add(f);
            this.pnl_Main_Clerk.Tag = f;
            f.Show();
        }

        private void Clerk_Load(object sender, EventArgs e)
        {

        }

        private void BTN_Apartment_Click(object sender, EventArgs e)
        {
            BUTTONColor();

            pnlnav.Height = BTN_Apartment.Height;
            pnlnav.Top = BTN_Apartment.Top;
            pnlnav.Left = BTN_Apartment.Left;

            lblHead.Text = "Apartment";
            BTN_Apartment.BackColor = Color.FromArgb(46, 51, 73);

            LoadForms(new Apartment());
        }

        private void BTN_Customer_Click(object sender, EventArgs e)
        {
            BUTTONColor();

            pnlnav.Height = BTN_Customer.Height;
            pnlnav.Top = BTN_Customer.Top;
            pnlnav.Left = BTN_Customer.Left;

            lblHead.Text = "Customer";
            BTN_Customer.BackColor = Color.FromArgb(46, 51, 73);

            LoadForms(new Customer());
        }

        private void BUTTONColor()
        {
            BTN_Dashboard.BackColor = Color.FromArgb(24, 30, 54);
            BTN_Customer.BackColor = Color.FromArgb(24, 30, 54);
            BTN_Apartment.BackColor = Color.FromArgb(24, 30, 54);
        }

        private void BTN_LOGOUT_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            this.Hide();
            login.Show();
        }

        private void BTN_Dashboard_Click(object sender, EventArgs e)
        {
            BUTTONColor();

            pnlnav.Height = BTN_Dashboard.Height;
            pnlnav.Top = BTN_Dashboard.Top;
            pnlnav.Left = BTN_Dashboard.Left;

            lblHead.Text = "Dashboard";
            BTN_Dashboard.BackColor = Color.FromArgb(46, 51, 73);

            LoadForms(new Dashboard());
        }

        private void Pnl_Main_Clerk_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
