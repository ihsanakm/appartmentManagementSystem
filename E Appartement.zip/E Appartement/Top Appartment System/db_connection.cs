﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace E_Appartment
{
    class db_connection
    {

        public static string con()
        {
            string connection = @"Data Source=DESKTOP-PBEM3OT\SQLEXPRESS;Initial Catalog=Top_Appartment;Integrated Security=True";
            return connection;
        }
    }
}
